import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import { createNormalAccount } from "../helpers/accounts.js";
import {
  impersonateLocalAccount,
  impersonateTimelock,
  stopImpersonatingLocalAccount,
} from "../helpers/governance.js";

const { ethers } = await network.create();

const WAD = 10n ** 18n;
const PRICE_DECIMALS = 8n;
const BPS = 10_000n;

const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const BIG_UP = 3_000n * 10n ** PRICE_DECIMALS;
const SETTLEMENT_DOWN = 1_720n * 10n ** PRICE_DECIMALS;

const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;
const BASE_SIZE = 10n ** 15n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const OrderSide = {
  Buy: 0,
  Sell: 1,
} as const;

type OrderSideValue = (typeof OrderSide)[keyof typeof OrderSide];

const PositionSide = {
  None: 0n,
  Long: 1n,
  Short: 2n,
} as const;

type AccountBundle = {
  account: any;
  owner: any;
  address: string;
};

function normalizePrice(
  rawPrice: bigint,
  oracleDecimals = 8n,
  marginDecimals = 18n,
): bigint {
  if (oracleDecimals === marginDecimals) return rawPrice;
  if (oracleDecimals < marginDecimals) {
    return rawPrice * 10n ** (marginDecimals - oracleDecimals);
  }
  return rawPrice / 10n ** (oracleDecimals - marginDecimals);
}

function initialMarginRequired(size: bigint, rawPrice: bigint): bigint {
  return (
    (size * MULTIPLIER * normalizePrice(rawPrice) * INITIAL_MARGIN_BPS) /
    (BPS * WAD)
  );
}

function pnlAbs(size: bigint, fromRaw: bigint, toRaw: bigint): bigint {
  const fromNorm = normalizePrice(fromRaw);
  const toNorm = normalizePrice(toRaw);
  const diff = fromNorm > toNorm ? fromNorm - toNorm : toNorm - fromNorm;
  return (size * MULTIPLIER * diff) / WAD;
}

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [
    pair,
    8,
    initialPrice,
  ]);
  await oracle.waitForDeployment();
  return oracle;
}

async function getActiveFuturesPriceManager(contracts: any) {
  const priceManagerAddress = await contracts.futuresContract.priceManager();

  expect(
    priceManagerAddress,
    "FuturesContract.priceManager is not set",
  ).to.not.equal(ethers.ZeroAddress);

  const code = await ethers.provider.getCode(priceManagerAddress);
  expect(
    code,
    `No code at FuturesContract.priceManager ${priceManagerAddress}`,
  ).to.not.equal("0x");

  return ethers.getContractAt("PriceManager", priceManagerAddress);
}

async function registerFuturesOracle(
  contracts: any,
  governance: any,
  oracle: any,
) {
  const oracleAddress = await oracle.getAddress();
  const priceManager = await getActiveFuturesPriceManager(contracts);

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (
      await priceManager.connect(governance).approveOracle(oracleAddress)
    ).wait();
  }

  if (
    !(await priceManager.isOracleApprovedFor(
      oracleAddress,
      OracleContext.FUTURE_SETTLEMENT,
    ))
  ) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (await priceManager.syncOracleData(oracleAddress)).wait();

  expect(await priceManager.isOracleUsableForFutures(oracleAddress)).to.equal(
    true,
  );

  return oracleAddress;
}

async function createFuturesMarket(
  contracts: any,
  governance: any,
  oracleAddress: string,
  label: string,
) {
  const marketKey =
    await contracts.futuresContract.computeMarketKey(oracleAddress);

  await (
    await contracts.futuresContract
      .connect(governance)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  const market = await contracts.futuresContract.getMarket(marketKey);
  expect(market.oracle).to.equal(oracleAddress);
  expect(market.lastSettlementPrice).to.equal(INITIAL_PRICE);

  return marketKey;
}

async function syncSettlement(
  contracts: any,
  oracle: any,
  oracleAddress: string,
  marketKey: string,
  price: bigint,
) {
  const priceManager = await getActiveFuturesPriceManager(contracts);

  await (await oracle.setPrice(price)).wait();
  await (await priceManager.syncOracleData(oracleAddress)).wait();
  await (await contracts.futuresContract.syncSettlementPrice(marketKey)).wait();

  expect(
    (await contracts.futuresContract.getMarket(marketKey)).lastSettlementPrice,
  ).to.equal(price);
}

async function depositEthToAccount(account: any, owner: any, amount: bigint) {
  await (
    await account
      .connect(owner)
      .depositETH(await account.getAddress(), await account.vault(), {
        value: amount,
      })
  ).wait();
}

async function createFundedAccount(
  contracts: any,
  owner: any,
  amount: bigint,
): Promise<AccountBundle> {
  const account = await createNormalAccount(
    ethers,
    contracts.accountFactory,
    contracts.accountRegistry,
    owner,
  );
  await depositEthToAccount(account, owner, amount);

  return {
    account,
    owner,
    address: await account.getAddress(),
  };
}

async function createFundedAccounts(
  contracts: any,
  owners: any[],
  amount: bigint,
): Promise<AccountBundle[]> {
  const out: AccountBundle[] = [];
  for (const owner of owners) {
    out.push(await createFundedAccount(contracts, owner, amount));
  }
  return out;
}

async function accountSigner(address: string) {
  return impersonateLocalAccount(ethers, address);
}

async function placeFuturesOrder(
  account: AccountBundle,
  futuresOrderBook: any,
  marketKey: string,
  side: OrderSideValue,
  price: bigint,
  size: bigint,
) {
  const signer = await accountSigner(account.address);

  const tx = await futuresOrderBook
    .connect(signer)
    .placeOrder(
      marketKey,
      side,
      price,
      size,
      0n,
      ethers.ZeroAddress,
      ethers.ZeroAddress,
    );

  await tx.wait();

  await stopImpersonatingLocalAccount(ethers, account.address);
}

async function openMatchedPair(
  contracts: any,
  short: AccountBundle,
  long: AccountBundle,
  marketKey: string,
  price: bigint,
  size: bigint,
) {
  const orderBook = contracts.futuresOrderBook;

  await placeFuturesOrder(
    short,
    orderBook,
    marketKey,
    OrderSide.Sell,
    price,
    size,
  );

  await placeFuturesOrder(
    long,
    orderBook,
    marketKey,
    OrderSide.Buy,
    price,
    size,
  );
}

async function addMargin(
  contracts: any,
  account: AccountBundle,
  marketKey: string,
  amount: bigint,
) {
  const signer = await accountSigner(account.address);
  const tx = await contracts.futuresContract
    .connect(signer)
    .addMargin(marketKey, amount);
  const receipt = await tx.wait();
  await stopImpersonatingLocalAccount(ethers, account.address);
  return receipt;
}

function findEvent(contracts: any, receipt: any, name: string): any | undefined {
  for (const log of receipt.logs) {
    try {
      const parsed = contracts.futuresContract.interface.parseLog(log);
      if (parsed?.name === name) return parsed;
    } catch {
      // Ignore logs from other contracts.
    }
  }
  return undefined;
}

function requireEvent(contracts: any, receipt: any, name: string): any {
  const event = findEvent(contracts, receipt, name);
  if (!event) throw new Error(`${name} event not found`);
  return event;
}

async function assertLiquidationBufferInvariant(
  contracts: any,
  marketKey: string,
) {
  expect(
    await contracts.futuresContract.liquidationSettlementBuffer(marketKey),
    "liquidation buffer accounting must not exceed settlement locked balance",
  ).to.be.lte(await contracts.vault.settlementEthLocked(marketKey));
}

async function setupImbalancedMarket(label: string) {
  const { addresses, contracts } = await loadIntegratedDeployment(ethers);
  const actors = await loadActors(ethers);
  const governance = await impersonateTimelock(
    ethers,
    addresses.sethxTimelock,
  );

  const oracle = await deployMockOracle(label, INITIAL_PRICE);
  const oracleAddress = await registerFuturesOracle(
    contracts,
    governance,
    oracle,
  );
  const marketKey = await createFuturesMarket(
    contracts,
    governance,
    oracleAddress,
    label,
  );

  const [shortLiquidated, longA, shortSolvent, longB] =
    await createFundedAccounts(
      contracts,
      [actors.alice, actors.bob, actors.carol, actors.dave],
      50n * WAD,
    );

  const liquidator = await createFundedAccount(
    contracts,
    actors.treasurer,
    10n * WAD,
  );

  await openMatchedPair(
    contracts,
    shortLiquidated,
    longA,
    marketKey,
    INITIAL_PRICE,
    BASE_SIZE,
  );
  await openMatchedPair(
    contracts,
    shortSolvent,
    longB,
    marketKey,
    INITIAL_PRICE,
    BASE_SIZE,
  );

  return {
    contracts,
    oracle,
    oracleAddress,
    marketKey,
    shortLiquidated,
    longA,
    shortSolvent,
    longB,
    liquidator,
  };
}

describe("Futures imbalance PnL payout integration", function () {
  this.timeout(240_000);

  it("caps an imbalanced long winner by peer coverage plus its pro-rata liquidation buffer share", async function () {
    const {
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      shortLiquidated,
      longA,
      shortSolvent,
      liquidator,
    } = await setupImbalancedMarket("FUT-IMBALANCE-PNL-A/USD");

    // Make one remaining short solvent enough to fund the peer-covered portion.
    await addMargin(contracts, shortSolvent, marketKey, 2n * WAD);

    await syncSettlement(contracts, oracle, oracleAddress, marketKey, BIG_UP);

    const liquidatorSigner = await accountSigner(liquidator.address);
    const liquidationTx = await contracts.futuresContract
      .connect(liquidatorSigner)
      .liquidatePosition(marketKey, shortLiquidated.address);
    const liquidationReceipt = await liquidationTx.wait();
    await stopImpersonatingLocalAccount(ethers, liquidator.address);

    const bufferIncrease = requireEvent(
      contracts,
      liquidationReceipt,
      "LiquidationSettlementBufferIncreased",
    );

    const liquidationBufferBefore =
      await contracts.futuresContract.liquidationSettlementBuffer(marketKey);

    expect(liquidationBufferBefore).to.equal(bufferIncrease.args.newBuffer);
    expect(liquidationBufferBefore).to.be.gt(0n);
    await assertLiquidationBufferInvariant(contracts, marketKey);

    expect(await contracts.futuresContract.totalLongs(marketKey)).to.equal(
      BASE_SIZE * 2n,
    );
    expect(await contracts.futuresContract.totalShorts(marketKey)).to.equal(
      BASE_SIZE,
    );

    const before = await contracts.futuresContract.getPosition(
      longA.address,
      marketKey,
    );
    const dustMargin = 1n;

    const receipt = await addMargin(contracts, longA, marketKey, dustMargin);

    const rawProfit = pnlAbs(BASE_SIZE, INITIAL_PRICE, BIG_UP);
    const normalCovered = rawProfit / 2n;
    const bufferPortion = liquidationBufferBefore / 2n;
    const correctedProfit = normalCovered + bufferPortion;

    const correctionEvent = requireEvent(
      contracts,
      receipt,
      "PositivePnlCorrectedForImbalance",
    );
    const bufferUsedEvent = requireEvent(
      contracts,
      receipt,
      "LiquidationSettlementBufferUsed",
    );

    expect(correctionEvent.args.account).to.equal(longA.address);
    expect(correctionEvent.args.marketKey).to.equal(marketKey);
    expect(correctionEvent.args.side).to.equal(PositionSide.Long);
    expect(correctionEvent.args.rawProfit).to.equal(rawProfit);
    expect(correctionEvent.args.correctedProfit).to.equal(correctedProfit);
    expect(correctionEvent.args.paidProfit).to.equal(correctedProfit);
    expect(correctionEvent.args.liquidationBufferPortion).to.equal(bufferPortion);
    expect(correctionEvent.args.totalLongs).to.equal(BASE_SIZE * 2n);
    expect(correctionEvent.args.totalShorts).to.equal(BASE_SIZE);

    expect(bufferUsedEvent.args.amount).to.equal(bufferPortion);
    expect(bufferUsedEvent.args.newBuffer).to.equal(
      liquidationBufferBefore - bufferPortion,
    );

    const after = await contracts.futuresContract.getPosition(
      longA.address,
      marketKey,
    );
    const paid = after.margin - before.margin - dustMargin;

    expect(paid, "realized margin increase equals corrected payout").to.equal(
      correctedProfit,
    );
    expect(after.referencePrice).to.equal(BIG_UP);
    expect(
      await contracts.futuresContract.liquidationSettlementBuffer(marketKey),
    ).to.equal(liquidationBufferBefore - bufferPortion);

    await assertLiquidationBufferInvariant(contracts, marketKey);
  });

  it("does not apply imbalance correction when the smaller side is the winner", async function () {
    const {
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      shortLiquidated,
      shortSolvent,
      liquidator,
    } = await setupImbalancedMarket("FUT-IMBALANCE-PNL-B/USD");

    await syncSettlement(contracts, oracle, oracleAddress, marketKey, BIG_UP);

    const liquidatorSigner = await accountSigner(liquidator.address);
    await (
      await contracts.futuresContract
        .connect(liquidatorSigner)
        .liquidatePosition(marketKey, shortLiquidated.address)
    ).wait();
    await stopImpersonatingLocalAccount(ethers, liquidator.address);

    const liquidationBufferBefore =
      await contracts.futuresContract.liquidationSettlementBuffer(marketKey);

    expect(liquidationBufferBefore).to.be.gt(0n);
    expect(await contracts.futuresContract.totalLongs(marketKey)).to.equal(
      BASE_SIZE * 2n,
    );
    expect(await contracts.futuresContract.totalShorts(marketKey)).to.equal(
      BASE_SIZE,
    );

    // Now price falls below the original reference. The smaller remaining short side wins.
    await syncSettlement(
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      SETTLEMENT_DOWN,
    );

    const before = await contracts.futuresContract.getPosition(
      shortSolvent.address,
      marketKey,
    );
    const dustMargin = 1n;

    const receipt = await addMargin(
      contracts,
      shortSolvent,
      marketKey,
      dustMargin,
    );

    expect(
      findEvent(contracts, receipt, "PositivePnlCorrectedForImbalance"),
      "smaller winning side should not emit correction event",
    ).to.equal(undefined);

    expect(
      findEvent(contracts, receipt, "LiquidationSettlementBufferUsed"),
      "smaller winning side should not consume liquidation buffer",
    ).to.equal(undefined);

    const rawProfit = pnlAbs(BASE_SIZE, INITIAL_PRICE, SETTLEMENT_DOWN);
    const after = await contracts.futuresContract.getPosition(
      shortSolvent.address,
      marketKey,
    );
    const paid = after.margin - before.margin - dustMargin;

    expect(paid).to.equal(rawProfit);
    expect(after.referencePrice).to.equal(SETTLEMENT_DOWN);
    expect(
      await contracts.futuresContract.liquidationSettlementBuffer(marketKey),
    ).to.equal(liquidationBufferBefore);

    await assertLiquidationBufferInvariant(contracts, marketKey);
  });

  it("allows treasurer-style loser rebasing to prefill settlement balance before imbalanced winner payout", async function () {
    const {
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      shortLiquidated,
      longA,
      shortSolvent,
      liquidator,
    } = await setupImbalancedMarket("FUT-IMBALANCE-PNL-C/USD");

    await addMargin(contracts, shortSolvent, marketKey, 2n * WAD);
    await syncSettlement(contracts, oracle, oracleAddress, marketKey, BIG_UP);

    const liquidatorSigner = await accountSigner(liquidator.address);
    await (
      await contracts.futuresContract
        .connect(liquidatorSigner)
        .liquidatePosition(marketKey, shortLiquidated.address)
    ).wait();
    await stopImpersonatingLocalAccount(ethers, liquidator.address);

    const liquidationBufferBefore =
      await contracts.futuresContract.liquidationSettlementBuffer(marketKey);
    const rawProfit = pnlAbs(BASE_SIZE, INITIAL_PRICE, BIG_UP);
    const normalCovered = rawProfit / 2n;
    const bufferPortion = liquidationBufferBefore / 2n;
    const correctedProfit = normalCovered + bufferPortion;

    const targetSettlementBuffer = liquidationBufferBefore + normalCovered;

    const maintenanceTx = await contracts.futuresContract.rebaseLosingPositionsToBufferTarget(
      marketKey,
      PositionSide.Short,
      targetSettlementBuffer,
      10n,
    );
    const maintenanceReceipt = await maintenanceTx.wait();
    const maintenanceEvent = requireEvent(
      contracts,
      maintenanceReceipt,
      "LosingPositionsRebased",
    );

    expect(maintenanceEvent.args.side).to.equal(PositionSide.Short);
    expect(maintenanceEvent.args.scanned).to.be.gt(0n);
    expect(maintenanceEvent.args.rebased).to.be.gt(0n);
    expect(maintenanceEvent.args.amountCollected).to.be.gte(normalCovered);
    expect(await contracts.vault.settlementEthLocked(marketKey)).to.be.gte(
      targetSettlementBuffer,
    );

    const before = await contracts.futuresContract.getPosition(
      longA.address,
      marketKey,
    );
    const dustMargin = 1n;
    const receipt = await addMargin(contracts, longA, marketKey, dustMargin);

    const correctionEvent = requireEvent(
      contracts,
      receipt,
      "PositivePnlCorrectedForImbalance",
    );

    expect(correctionEvent.args.rawProfit).to.equal(rawProfit);
    expect(correctionEvent.args.correctedProfit).to.equal(correctedProfit);
    expect(correctionEvent.args.paidProfit).to.equal(correctedProfit);
    expect(correctionEvent.args.liquidationBufferPortion).to.equal(bufferPortion);

    const after = await contracts.futuresContract.getPosition(
      longA.address,
      marketKey,
    );
    expect(after.margin - before.margin - dustMargin).to.equal(correctedProfit);

    await assertLiquidationBufferInvariant(contracts, marketKey);
  });
});
