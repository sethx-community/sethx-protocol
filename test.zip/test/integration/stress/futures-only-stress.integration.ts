import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import { createNormalAccount } from "../helpers/accounts.js";
import {
  impersonateLocalAccount,
  impersonateTimelock,
  stopImpersonatingLocalAccount,
} from "../helpers/governance.js";
import { expectRevert } from "../helpers/reverts.js";

function abs(value: bigint): bigint {
  return value < 0n ? -value : value;
}
const { ethers } = await network.create();

const ETH = ethers.ZeroAddress;
const WAD = 10n ** 18n;
const PRICE_DECIMALS = 8n;
const BPS = 10_000n;
const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const SETTLEMENT_UP = 2_180n * 10n ** PRICE_DECIMALS;
const BIG_UP = 3_000n * 10n ** PRICE_DECIMALS;
const SETTLEMENT_DOWN = 1_720n * 10n ** PRICE_DECIMALS;
const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;
const BASE_SIZE = 10n ** 15n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const OrderSide = {
  Buy: 0,
  Sell: 1,
} as const;

const PositionSide = {
  None: 0n,
  Long: 1n,
  Short: 2n,
} as const;

type AccountBundle = {
  account: any;
  owner: any;
  address: string;
};

const FEE_CONTEXT_FUTURES = "Futures Trade";

async function latestBlockTimestamp(): Promise<bigint> {
  const block = await ethers.provider.getBlock("latest");
  if (block === null) throw new Error("latest block unavailable");
  return BigInt(block.timestamp);
}

async function mineToTimestamp(timestamp: bigint) {
  const latest = await latestBlockTimestamp();
  if (latest >= timestamp) return;

  await ethers.provider.send("evm_setNextBlockTimestamp", [
    `0x${timestamp.toString(16)}`,
  ]);
  await ethers.provider.send("evm_mine", []);
}

async function activateFeeContextIfQueued(
  contracts: any,
  governance: any,
  contextName: string,
) {
  const activeBefore = await contracts.feeManager.getRoleFeeConfig(contextName);
  if (activeBefore.configured) return activeBefore;

  const pending = await contracts.feeManager.pendingRoleUpdates(contextName);
  expect(
    pending.executeAfter,
    `${contextName} fee update must be queued before the standalone futures stress test executes it`,
  ).to.be.gt(0n);

  await mineToTimestamp(pending.executeAfter);

  await (
    await contracts.feeManager
      .connect(governance)
      .executeRoleFeeUpdate(contextName)
  ).wait();

  const activeAfter = await contracts.feeManager.getRoleFeeConfig(contextName);
  expect(
    activeAfter.configured,
    `${contextName} fee config must be active after executing the queued update`,
  ).to.equal(true);

  return activeAfter;
}

function normalizePriceRaw(
  rawPrice: bigint,
  oracleDecimals: bigint,
  marginDecimals: bigint,
): bigint {
  if (oracleDecimals === marginDecimals) return rawPrice;

  if (oracleDecimals < marginDecimals) {
    return rawPrice * 10n ** (marginDecimals - oracleDecimals);
  }

  return rawPrice / 10n ** (oracleDecimals - marginDecimals);
}

async function futuresNotionalFromPrice(
  contracts: any,
  marketKey: string,
  size: bigint,
  rawPrice: bigint,
): Promise<bigint> {
  const market = await contracts.futuresContract.getMarket(marketKey);

  const priceNorm = normalizePriceRaw(
    rawPrice,
    BigInt(market.oraclePriceDecimals),
    BigInt(market.marginDecimals),
  );

  return (
    (size * market.multiplier * priceNorm) /
    10n ** BigInt(market.marginDecimals)
  );
}

async function previewFuturesMakerFee(
  contracts: any,
  accountAddress: string,
  marketKey: string,
  size: bigint,
  rawPrice: bigint,
): Promise<bigint> {
  const feeBase = await futuresNotionalFromPrice(
    contracts,
    marketKey,
    size,
    rawPrice,
  );

  const fee = await contracts.feeManager.getFeeForAccount(
    ethers.ZeroAddress, // paymentToken: ETH
    ethers.ZeroAddress, // assetToken: ETH/futures notional fallback
    feeBase,
    FEE_CONTEXT_FUTURES,
    accountAddress,
    true, // isMaker
  );

  return fee.fixedAmount + fee.percentageAmount;
}

async function requireConfiguredFuturesMakerFee(
  contracts: any,
  accountAddress: string,
  marketKey: string,
  size: bigint,
  rawPrice: bigint,
) {
  const config =
    await contracts.feeManager.getRoleFeeConfig(FEE_CONTEXT_FUTURES);

  expect(
    config.configured,
    "FeeManager role fee config for Futures Trade must be active; execute queued fee update first",
  ).to.equal(true);

  const preview = await previewFuturesMakerFee(
    contracts,
    accountAddress,
    marketKey,
    size,
    rawPrice,
  );

  expect(
    preview,
    `FeeManager preview for Futures Trade maker fee should be nonzero for ${accountAddress}`,
  ).to.be.gt(0n);

  return preview;
}

function normalizePrice(
  rawPrice: bigint,
  oracleDecimals = 8n,
  marginDecimals = 18n,
): bigint {
  if (oracleDecimals === marginDecimals) return rawPrice;
  if (oracleDecimals < marginDecimals)
    return rawPrice * 10n ** (marginDecimals - oracleDecimals);
  return rawPrice / 10n ** (oracleDecimals - marginDecimals);
}

function initialMarginRequired(size: bigint, rawPrice: bigint): bigint {
  return (
    (size * MULTIPLIER * normalizePrice(rawPrice) * INITIAL_MARGIN_BPS) /
    (BPS * WAD)
  );
}

function maintenanceRequired(size: bigint, rawPrice: bigint): bigint {
  return (
    (size * MULTIPLIER * normalizePrice(rawPrice) * MAINTENANCE_MARGIN_BPS) /
    (BPS * WAD)
  );
}

function pnlAbs(size: bigint, fromRaw: bigint, toRaw: bigint): bigint {
  const fromNorm = normalizePrice(fromRaw);
  const toNorm = normalizePrice(toRaw);
  const diff = fromNorm > toNorm ? fromNorm - toNorm : toNorm - fromNorm;
  return (size * MULTIPLIER * diff) / WAD;
}

function isOpenPosition(p: any): boolean {
  return (
    p.size > 0n &&
    (p.side === PositionSide.Long || p.side === PositionSide.Short)
  );
}

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [
    pair,
    8,
    initialPrice,
  ]);
  await oracle.waitForDeployment();
  return oracle;
}

async function getActiveFuturesPriceManager(contracts: any) {
  const priceManagerAddress = await contracts.futuresContract.priceManager();

  expect(
    priceManagerAddress,
    "FuturesContract.priceManager is not set",
  ).to.not.equal(ethers.ZeroAddress);

  const code = await ethers.provider.getCode(priceManagerAddress);
  expect(
    code,
    `No code at FuturesContract.priceManager ${priceManagerAddress}`,
  ).to.not.equal("0x");

  return ethers.getContractAt("PriceManager", priceManagerAddress);
}

async function registerFuturesOracle(
  contracts: any,
  governance: any,
  oracle: any,
) {
  const oracleAddress = await oracle.getAddress();
  const priceManager = await getActiveFuturesPriceManager(contracts);

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (
      await priceManager.connect(governance).approveOracle(oracleAddress)
    ).wait();
  }

  if (
    !(await priceManager.isOracleApprovedFor(
      oracleAddress,
      OracleContext.FUTURE_SETTLEMENT,
    ))
  ) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (await priceManager.syncOracleData(oracleAddress)).wait();

  expect(await priceManager.isOracleUsableForFutures(oracleAddress)).to.equal(
    true,
  );

  return oracleAddress;
}

async function createFuturesMarket(
  contracts: any,
  governance: any,
  oracleAddress: string,
  label: string,
) {
  const marketKey =
    await contracts.futuresContract.computeMarketKey(oracleAddress);

  await (
    await contracts.futuresContract
      .connect(governance)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  const market = await contracts.futuresContract.getMarket(marketKey);
  expect(market.oracle).to.equal(oracleAddress);
  expect(market.lastSettlementPrice).to.equal(INITIAL_PRICE);

  return marketKey;
}

async function syncSettlement(
  contracts: any,
  oracle: any,
  oracleAddress: string,
  marketKey: string,
  price: bigint,
) {
  const priceManager = await getActiveFuturesPriceManager(contracts);

  await (await oracle.setPrice(price)).wait();
  await (await priceManager.syncOracleData(oracleAddress)).wait();
  await (await contracts.futuresContract.syncSettlementPrice(marketKey)).wait();

  expect(
    (await contracts.futuresContract.getMarket(marketKey)).lastSettlementPrice,
  ).to.equal(price);
}

async function depositEthToAccount(account: any, owner: any, amount: bigint) {
  await (
    await account
      .connect(owner)
      .depositETH(await account.getAddress(), await account.vault(), {
        value: amount,
      })
  ).wait();
}

async function createFundedAccount(
  contracts: any,
  owner: any,
  amount: bigint,
): Promise<AccountBundle> {
  const account = await createNormalAccount(
    ethers,
    contracts.accountFactory,
    contracts.accountRegistry,
    owner,
  );
  await depositEthToAccount(account, owner, amount);

  return {
    account,
    owner,
    address: await account.getAddress(),
  };
}

async function createFundedAccounts(
  contracts: any,
  owners: any[],
  amount: bigint,
): Promise<AccountBundle[]> {
  const out: AccountBundle[] = [];
  for (const owner of owners) {
    out.push(await createFundedAccount(contracts, owner, amount));
  }
  return out;
}

async function placeFuturesOrderReturningId(
  contracts: any,
  account: any,
  futuresOrderBook: any,
  marketKey: string,
  side: OrderSide,
  price: bigint,
  size: bigint,
): Promise<bigint> {
  const orderId = await contracts.futuresOrderBook.nextOrderId();

  await placeFuturesOrder(
    account,
    futuresOrderBook,
    marketKey,
    side,
    price,
    size,
  );

  const order = await contracts.futuresOrderBook.ordersById(orderId);

  expect(
    order.orderId,
    `expected order ${orderId} to exist after placement`,
  ).to.equal(orderId);

  return orderId;
}

async function getOrderFeeRemaining(
  contracts: any,
  orderId: bigint,
): Promise<bigint> {
  const order = await contracts.futuresOrderBook.ordersById(orderId);

  if (order.orderId === 0n) {
    return 0n;
  }

  const fixedRemaining = order.fixedFeeCharged ? 0n : order.fixedFeeTotal;
  const pctRemaining =
    order.pctFeeTotal > order.pctFeeCharged
      ? order.pctFeeTotal - order.pctFeeCharged
      : 0n;

  return fixedRemaining + pctRemaining;
}

async function getOrdersFeeRemaining(
  contracts: any,
  orderIds: bigint[],
): Promise<bigint> {
  let total = 0n;

  for (const orderId of orderIds) {
    total += await getOrderFeeRemaining(contracts, orderId);
  }

  return total;
}

function parseImbalanceMatched(
  contracts: any,
  receipt: any,
): { callerReward: bigint; protocolFee: bigint; amount: bigint } {
  for (const log of receipt.logs) {
    try {
      const parsed = contracts.futuresOrderBook.interface.parseLog(log);

      if (parsed?.name === "ImbalanceMatched") {
        return {
          amount: parsed.args.amount,
          callerReward: parsed.args.callerReward,
          protocolFee: parsed.args.protocolFee,
        };
      }
    } catch {
      // Ignore logs from other contracts.
    }
  }

  throw new Error("ImbalanceMatched event not found");
}
async function placeFuturesOrder(
  account: any,
  futuresOrderBook: any,
  marketKey: string,
  side: OrderSide,
  price: bigint,
  size: bigint,
) {
  const signer = await accountSigner(account.address);

  const tx = await futuresOrderBook
    .connect(signer)
    .placeOrder(
      marketKey,
      side,
      price,
      size,
      0n,
      ethers.ZeroAddress,
      ethers.ZeroAddress,
    );

  await tx.wait();

  await stopImpersonatingLocalAccount(ethers, account.address);
}

async function openMatchedPair(
  contracts: any,
  short: AccountBundle,
  long: AccountBundle,
  marketKey: string,
  price: bigint,
  size: bigint,
) {
  const orderBook = contracts.futuresOrderBook;

  await placeFuturesOrder(
    short,
    orderBook,
    marketKey,
    OrderSide.Sell,
    price,
    size,
  );

  await placeFuturesOrder(
    long,
    orderBook,
    marketKey,
    OrderSide.Buy,
    price,
    size,
  );
}

async function accountSigner(address: string) {
  return impersonateLocalAccount(ethers, address);
}

async function assertOpenPosition(
  contracts: any,
  account: string,
  marketKey: string,
  side: bigint,
  size: bigint,
) {
  const p = await contracts.futuresContract.getPosition(account, marketKey);
  expect(isOpenPosition(p), `position ${account} open`).to.equal(true);
  expect(p.side, `position ${account} side`).to.equal(side);
  expect(p.size, `position ${account} size`).to.equal(size);
  return p;
}

async function assertGlobalFuturesInvariants(
  contracts: any,
  marketKey: string,
  accounts: AccountBundle[],
) {
  let summedLongs = 0n;
  let summedShorts = 0n;

  for (const bundle of accounts) {
    const p = await contracts.futuresContract.getPosition(
      bundle.address,
      marketKey,
    );
    if (p.size === 0n) continue;

    expect(
      p.side === PositionSide.Long || p.side === PositionSide.Short,
      `invalid side for ${bundle.address}`,
    ).to.equal(true);

    const health = await contracts.futuresContract.positionHealth(
      marketKey,
      bundle.address,
    );

    expect(health.position.size, `health size for ${bundle.address}`).to.equal(
      p.size,
    );
    expect(health.position.side, `health side for ${bundle.address}`).to.equal(
      p.side,
    );

    const shouldBeLiquidatable = health.liveMargin < health.maintenanceMargin;

    expect(
      health.liquidatable,
      `health liquidation flag for ${bundle.address}`,
    ).to.equal(shouldBeLiquidatable);

    if (p.margin === 0n) {
      expect(
        health.unrealizedPnl > 0n || health.liquidatable,
        `zero-margin position must be supported by positive PnL or be liquidatable for ${bundle.address}`,
      ).to.equal(true);
    }

    expect(p.referencePrice, `reference price for ${bundle.address}`).to.be.gt(
      0n,
    );
    expect(
      p.liquidationPrice,
      `liquidation price for ${bundle.address}`,
    ).to.be.gt(0n);

    const node = await contracts.futuresContract.getLiquidationNode(
      marketKey,
      bundle.address,
    );
    expect(
      node.active,
      `liquidation node active for ${bundle.address}`,
    ).to.equal(true);
    expect(node.side, `liquidation node side for ${bundle.address}`).to.equal(
      p.side,
    );
    expect(
      node.liquidationPrice,
      `liquidation node price for ${bundle.address}`,
    ).to.equal(p.liquidationPrice);
    expect(
      node.liquidationTick,
      `liquidation node tick for ${bundle.address}`,
    ).to.equal(p.liquidationTick);

    const anchor = await contracts.futuresContract.getLiquidationTickAnchor(
      marketKey,
      p.side,
      p.liquidationTick,
    );
    if (anchor !== ethers.ZeroAddress) {
      const anchorNode = await contracts.futuresContract.getLiquidationNode(
        marketKey,
        anchor,
      );
      expect(
        anchorNode.active,
        `anchor active for tick ${p.liquidationTick}`,
      ).to.equal(true);
      expect(
        anchorNode.side,
        `anchor side for tick ${p.liquidationTick}`,
      ).to.equal(p.side);
      expect(anchorNode.liquidationTick, `anchor tick`).to.equal(
        p.liquidationTick,
      );
    }

    if (p.side === PositionSide.Long) summedLongs += p.size;
    if (p.side === PositionSide.Short) summedShorts += p.size;
  }

  expect(
    await contracts.futuresContract.totalLongs(marketKey),
    "summed total longs",
  ).to.equal(summedLongs);
  expect(
    await contracts.futuresContract.totalShorts(marketKey),
    "summed total shorts",
  ).to.equal(summedShorts);
  expect(
    await contracts.futuresContract.getOpenInterestImbalance(marketKey),
    "imbalance identity",
  ).to.equal(summedLongs - summedShorts);
}

async function assertListSortedAndCounted(
  contracts: any,
  marketKey: string,
  side: bigint,
  expectedCountUpperBound: number,
) {
  const list = await contracts.futuresContract.getLiquidationList(
    marketKey,
    side,
  );
  let current = list.head;
  let previousPrice: bigint | undefined;
  let count = 0n;

  while (current !== ethers.ZeroAddress) {
    expect(count, "liquidation list loop guard").to.be.lt(
      BigInt(expectedCountUpperBound + 5),
    );

    const node = await contracts.futuresContract.getLiquidationNode(
      marketKey,
      current,
    );
    expect(node.active, "node active in list").to.equal(true);
    expect(node.side, "node side in list").to.equal(side);

    if (previousPrice !== undefined) {
      if (side === PositionSide.Long) {
        expect(previousPrice, "long list sorted high to low").to.be.gte(
          node.liquidationPrice,
        );
      } else {
        expect(previousPrice, "short list sorted low to high").to.be.lte(
          node.liquidationPrice,
        );
      }
    }

    previousPrice = node.liquidationPrice;
    current = node.next;
    count++;
  }

  expect(list.count, "liquidation list count").to.equal(count);
}

describe("Futures-only stress integration", function () {
  this.timeout(240_000);

  it("stress-tests many normal orders, partial fills, flips, equal liquidation ticks, and index invariants", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const governance = await impersonateTimelock(
      ethers,
      addresses.sethxTimelock,
    );

    const oracle = await deployMockOracle("FUT-STRESS-A/USD", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(
      contracts,
      governance,
      oracle,
    );
    const marketKey = await createFuturesMarket(
      contracts,
      governance,
      oracleAddress,
      "FUT-STRESS-A",
    );
    const orderBook = contracts.futuresOrderBook;

    const accounts = await createFundedAccounts(
      contracts,
      [
        actors.alice,
        actors.bob,
        actors.carol,
        actors.dave,
        actors.lp1,
        actors.lp2,
        actors.attacker,
      ],
      8n * WAD,
    );

    const [shortA, shortB, shortC, longA, longB, longC, flipper] = accounts;
    const sizes = [
      BASE_SIZE,
      BASE_SIZE * 2n,
      BASE_SIZE / 2n,
      BASE_SIZE,
      (BASE_SIZE * 3n) / 2n,
    ];

    // Build multiple equal-price and equal-tick positions across both sides.
    await openMatchedPair(
      contracts,
      shortA,
      longA,
      marketKey,
      INITIAL_PRICE,
      sizes[0],
    );
    await openMatchedPair(
      contracts,
      shortB,
      longB,
      marketKey,
      INITIAL_PRICE,
      sizes[1],
    );
    await openMatchedPair(
      contracts,
      shortC,
      longC,
      marketKey,
      INITIAL_PRICE,
      sizes[2],
    );

    // Increase some positions and make sure repeated reindexing does not corrupt equal liquidation-price lists.
    await placeFuturesOrder(
      shortA,
      orderBook,
      marketKey,
      OrderSide.Sell,
      INITIAL_PRICE,
      sizes[3],
    );
    await placeFuturesOrder(
      longB,
      orderBook,
      marketKey,
      OrderSide.Buy,
      INITIAL_PRICE,
      sizes[3],
    );

    // Flip one account from no position into long, then close/reverse through the same matching surface.
    await placeFuturesOrder(
      shortB,
      orderBook,
      marketKey,
      OrderSide.Sell,
      INITIAL_PRICE,
      sizes[4],
    );
    await placeFuturesOrder(
      flipper,
      orderBook,
      marketKey,
      OrderSide.Buy,
      INITIAL_PRICE,
      sizes[4],
    );
    await assertOpenPosition(
      contracts,
      flipper.address,
      marketKey,
      PositionSide.Long,
      sizes[4],
    );

    await placeFuturesOrder(
      flipper,
      orderBook,
      marketKey,
      OrderSide.Sell,
      INITIAL_PRICE,
      sizes[4] + BASE_SIZE / 2n,
    );
    await placeFuturesOrder(
      longA,
      orderBook,
      marketKey,
      OrderSide.Buy,
      INITIAL_PRICE,
      sizes[4] + BASE_SIZE / 2n,
    );
    await assertOpenPosition(
      contracts,
      flipper.address,
      marketKey,
      PositionSide.Short,
      BASE_SIZE / 2n,
    );

    // Add and release excess margin to force another liquidation-index reinsert path.
    const flipperSigner = await accountSigner(flipper.address);
    await (
      await contracts.futuresContract
        .connect(flipperSigner)
        .addMargin(marketKey, initialMarginRequired(BASE_SIZE, INITIAL_PRICE))
    ).wait();
    await (
      await contracts.futuresContract
        .connect(flipperSigner)
        .releaseExcessMargin(marketKey)
    ).wait();
    await stopImpersonatingLocalAccount(ethers, flipper.address);

    await assertGlobalFuturesInvariants(contracts, marketKey, accounts);
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Long,
      accounts.length,
    );
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Short,
      accounts.length,
    );
  });

  it("stress-tests settlement rebases, virtual margin/health math, and insufficient settlement buffer behavior", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const governance = await impersonateTimelock(
      ethers,
      addresses.sethxTimelock,
    );

    const oracle = await deployMockOracle("FUT-STRESS-B/USD", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(
      contracts,
      governance,
      oracle,
    );
    const marketKey = await createFuturesMarket(
      contracts,
      governance,
      oracleAddress,
      "FUT-STRESS-B",
    );
    const orderBook = contracts.futuresOrderBook;

    const accounts = await createFundedAccounts(
      contracts,
      [
        actors.alice,
        actors.bob,
        actors.carol,
        actors.dave,
        actors.lp1,
        actors.lp2,
      ],
      20n * WAD,
    );

    const [shortA, longA, shortB, longB, shortC, longC] = accounts;
    const size = BASE_SIZE * 2n;
    const initialMargin = initialMarginRequired(size, INITIAL_PRICE);

    await openMatchedPair(
      contracts,
      shortA,
      longA,
      marketKey,
      INITIAL_PRICE,
      size,
    );
    await openMatchedPair(
      contracts,
      shortB,
      longB,
      marketKey,
      INITIAL_PRICE,
      size,
    );
    await openMatchedPair(
      contracts,
      shortC,
      longC,
      marketKey,
      INITIAL_PRICE,
      size,
    );

    // Price rises sharply. Longs are winners; shorts are losers. Profit request exceeds what one loser can buffer.
    await syncSettlement(contracts, oracle, oracleAddress, marketKey, BIG_UP);
    const expectedProfit = pnlAbs(size, INITIAL_PRICE, BIG_UP);
    expect(
      expectedProfit,
      "profit exceeds one initial margin to exercise partial buffer path",
    ).to.be.gt(initialMargin);

    // Trigger a long mutation. The contract should rebase losers from head, pay only available buffer,
    // and never mint virtual margin beyond collected settlement buffer.
    await placeFuturesOrder(
      shortA,
      orderBook,
      marketKey,
      OrderSide.Sell,
      BIG_UP,
      BASE_SIZE,
    );
    await placeFuturesOrder(
      longA,
      orderBook,
      marketKey,
      OrderSide.Buy,
      BIG_UP,
      BASE_SIZE,
    );

    const longAPosition = await contracts.futuresContract.getPosition(
      longA.address,
      marketKey,
    );
    const shortAPosition = await contracts.futuresContract.getPosition(
      shortA.address,
      marketKey,
    );
    const health = await contracts.futuresContract.positionHealth(
      marketKey,
      longA.address,
    );

    expect(longAPosition.referencePrice).to.equal(BIG_UP);
    expect(
      longAPosition.margin,
      "long received at least some realized settlement profit plus new margin",
    ).to.be.gt(initialMargin + initialMarginRequired(BASE_SIZE, BIG_UP));
    expect(
      longAPosition.margin,
      "long cannot receive more than requested profit plus trade margin",
    ).to.be.lte(
      initialMargin + expectedProfit + initialMarginRequired(BASE_SIZE, BIG_UP),
    );
    expect(shortAPosition.referencePrice).to.equal(BIG_UP);
    expect(
      await contracts.vault.settlementEthLocked(marketKey),
      "buffer should not go negative and may be drained",
    ).to.be.gte(0n);

    const expectedMaintenance = maintenanceRequired(longAPosition.size, BIG_UP);
    expect(health.position.size).to.equal(longAPosition.size);
    expect(
      health.liveMargin,
      "health live margin equals current margin after reference sync",
    ).to.equal(longAPosition.margin);
    expect(
      health.maintenanceMargin,
      "maintenance calculation at settlement price",
    ).to.equal(expectedMaintenance);
    expect(health.liquidatable).to.equal(
      health.liveMargin < health.maintenanceMargin,
    );

    // Move down and mutate a short. This exercises the opposite-side settlement path and list ordering.
    await syncSettlement(
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      SETTLEMENT_DOWN,
    );
    await placeFuturesOrder(
      shortB,
      orderBook,
      marketKey,
      OrderSide.Sell,
      SETTLEMENT_DOWN,
      BASE_SIZE / 2n,
    );
    await placeFuturesOrder(
      longB,
      orderBook,
      marketKey,
      OrderSide.Buy,
      SETTLEMENT_DOWN,
      BASE_SIZE / 2n,
    );

    const shortBHealth = await contracts.futuresContract.positionHealth(
      marketKey,
      shortB.address,
    );
    expect(shortBHealth.position.referencePrice).to.equal(SETTLEMENT_DOWN);
    expect(shortBHealth.liveMargin).to.equal(shortBHealth.position.margin);

    await assertGlobalFuturesInvariants(contracts, marketKey, accounts);
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Long,
      accounts.length,
    );
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Short,
      accounts.length,
    );
  });

  it("stress-tests batch liquidations, liquidation rewards, stale imbalance protection, and imbalance matching rewards", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const governance = await impersonateTimelock(
      ethers,
      addresses.sethxTimelock,
    );

    const oracle = await deployMockOracle("FUT-STRESS-C/USD", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(
      contracts,
      governance,
      oracle,
    );
    const marketKey = await createFuturesMarket(
      contracts,
      governance,
      oracleAddress,
      "FUT-STRESS-C",
    );
    const orderBook = contracts.futuresOrderBook;

    const accounts = await createFundedAccounts(
      contracts,
      [
        actors.alice,
        actors.bob,
        actors.carol,
        actors.dave,
        actors.lp1,
        actors.lp2,
        actors.attacker,
      ],
      15n * WAD,
    );

    const [shortA, longA, shortB, longB, shortC, longC, matcher] = accounts;
    const liquidator = await createFundedAccount(
      contracts,
      actors.treasurer,
      10n * WAD,
    );

    await openMatchedPair(
      contracts,
      shortA,
      longA,
      marketKey,
      INITIAL_PRICE,
      BASE_SIZE,
    );
    await openMatchedPair(
      contracts,
      shortB,
      longB,
      marketKey,
      INITIAL_PRICE,
      BASE_SIZE,
    );
    await openMatchedPair(
      contracts,
      shortC,
      longC,
      marketKey,
      INITIAL_PRICE,
      BASE_SIZE,
    );

    await syncSettlement(
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      SETTLEMENT_UP,
    );

    const liquidatorBefore = await contracts.vault.ethBalances(
      liquidator.address,
    );
    const liquidatorSigner = await accountSigner(liquidator.address);

    await (
      await contracts.futuresContract
        .connect(liquidatorSigner)
        .liquidatePosition(marketKey, shortA.address)
    ).wait();
    await (
      await contracts.futuresContract
        .connect(liquidatorSigner)
        .liquidateHead(marketKey, PositionSide.Short, 10n)
    ).wait();

    await stopImpersonatingLocalAccount(ethers, liquidator.address);

    expect(
      await contracts.vault.ethBalances(liquidator.address),
      "liquidator receives rewards",
    ).to.be.gt(liquidatorBefore);
    expect(
      await contracts.futuresContract.totalShorts(marketKey),
      "all unsafe shorts removed",
    ).to.equal(0n);
    expect(
      await contracts.futuresContract.totalLongs(marketKey),
      "long side remains after short liquidations",
    ).to.equal(BASE_SIZE * 3n);
    expect(
      await contracts.futuresContract.getOpenInterestImbalance(marketKey),
    ).to.equal(BASE_SIZE * 3n);
    expect(
      await contracts.vault.settlementEthLocked(marketKey),
      "seized margin remainder is settlement buffer",
    ).to.be.gt(0n);

    // Imbalance matching should require fresh settlement data.
    await (
      await contracts.futuresContract
        .connect(governance)
        .setMaxImbalanceSettlementAge(1n)
    ).wait();
    await ethers.provider.send("evm_increaseTime", [2]);
    await ethers.provider.send("evm_mine", []);
    const matcherSigner = await accountSigner(matcher.address);
    await expectRevert(
      contracts.futuresOrderBook
        .connect(matcherSigner)
        .matchImbalance(marketKey, 10n),
    );
    await stopImpersonatingLocalAccount(ethers, matcher.address);

    // Refresh, restore a reasonable max age, then place standing sell orders against the synthetic long maker.
    await (
      await contracts.futuresContract
        .connect(governance)
        .setMaxImbalanceSettlementAge(3600n)
    ).wait();
    await syncSettlement(
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      SETTLEMENT_UP,
    );

    const imbalanceOrderIds: bigint[] = [];

    await activateFeeContextIfQueued(
      contracts,
      governance,
      FEE_CONTEXT_FUTURES,
    );

    const expectedFeeShortA = await requireConfiguredFuturesMakerFee(
      contracts,
      shortA.address,
      marketKey,
      BASE_SIZE,
      SETTLEMENT_UP,
    );

    const expectedFeeShortB = await requireConfiguredFuturesMakerFee(
      contracts,
      shortB.address,
      marketKey,
      BASE_SIZE,
      SETTLEMENT_UP,
    );

    const expectedFeeShortC = await requireConfiguredFuturesMakerFee(
      contracts,
      shortC.address,
      marketKey,
      BASE_SIZE,
      SETTLEMENT_UP,
    );

    const expectedFeeTotal =
      expectedFeeShortA + expectedFeeShortB + expectedFeeShortC;

    expect(
      expectedFeeTotal,
      "FeeManager preview should show nonzero total maker fee for imbalance orders",
    ).to.be.gt(0n);

    imbalanceOrderIds.push(
      await placeFuturesOrderReturningId(
        contracts,
        shortA,
        orderBook,
        marketKey,
        OrderSide.Sell,
        SETTLEMENT_UP,
        BASE_SIZE,
      ),
    );

    imbalanceOrderIds.push(
      await placeFuturesOrderReturningId(
        contracts,
        shortB,
        orderBook,
        marketKey,
        OrderSide.Sell,
        SETTLEMENT_UP,
        BASE_SIZE,
      ),
    );

    imbalanceOrderIds.push(
      await placeFuturesOrderReturningId(
        contracts,
        shortC,
        orderBook,
        marketKey,
        OrderSide.Sell,
        SETTLEMENT_UP,
        BASE_SIZE,
      ),
    );

    const feeRemainingBefore = await getOrdersFeeRemaining(
      contracts,
      imbalanceOrderIds,
    );

    expect(
      feeRemainingBefore,
      "standing imbalance orders must have nonzero fee budget before matchImbalance",
    ).to.be.gt(0n);

    const imbalanceBefore =
      await contracts.futuresContract.getOpenInterestImbalance(marketKey);

    const matcherBefore = await contracts.vault.ethBalances(matcher.address);

    const matcherSigner2 = await accountSigner(matcher.address);

    const matchTx = await contracts.futuresOrderBook
      .connect(matcherSigner2)
      .matchImbalance(marketKey, 10n);

    const matchReceipt = await matchTx.wait();

    await stopImpersonatingLocalAccount(ethers, matcher.address);

    const imbalanceEvent = parseImbalanceMatched(contracts, matchReceipt);

    const matcherAfter = await contracts.vault.ethBalances(matcher.address);
    const imbalanceAfter =
      await contracts.futuresContract.getOpenInterestImbalance(marketKey);

    const feeRemainingAfter = await getOrdersFeeRemaining(
      contracts,
      imbalanceOrderIds,
    );

    const feeConsumed = feeRemainingBefore - feeRemainingAfter;
    const matcherReward = matcherAfter - matcherBefore;

    expect(abs(imbalanceAfter), "imbalance should decrease").to.be.lt(
      abs(imbalanceBefore),
    );

    expect(
      imbalanceEvent.amount,
      "ImbalanceMatched event should report matched amount",
    ).to.be.gt(0n);

    expect(
      feeConsumed,
      "matchImbalance should consume fee budget from standing imbalance orders",
    ).to.be.gt(0n);

    expect(
      imbalanceEvent.callerReward,
      "ImbalanceMatched event should report caller reward",
    ).to.be.gt(0n);

    expect(
      matcherReward,
      "matcher receives imbalance fee share in vault ETH balance",
    ).to.equal(imbalanceEvent.callerReward);

    expect(await contracts.futuresContract.totalShorts(marketKey)).to.equal(
      BASE_SIZE * 3n,
    );
    expect(await contracts.futuresContract.totalLongs(marketKey)).to.equal(
      BASE_SIZE * 3n,
    );
    expect(
      await contracts.futuresContract.getOpenInterestImbalance(marketKey),
    ).to.equal(0n);

    await assertGlobalFuturesInvariants(contracts, marketKey, [
      longA,
      longB,
      longC,
      shortA,
      shortB,
      shortC,
      matcher,
      liquidator,
    ]);
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Long,
      accounts.length + 1,
    );
    await assertListSortedAndCounted(
      contracts,
      marketKey,
      PositionSide.Short,
      accounts.length + 1,
    );
  });
});
