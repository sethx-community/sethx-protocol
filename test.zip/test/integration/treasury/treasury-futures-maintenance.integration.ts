import { expect } from "chai";
import { network } from "hardhat";

import {
  readLocalDeployment,
  requireLocalAddress,
} from "../../helpers/deployment-reader.js";
import { impersonateTimelock } from "../helpers/governance.js";

const { ethers } = await network.create();

const PRICE_DECIMALS = 8n;
const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const UPDATED_PRICE = 2_050n * 10n ** PRICE_DECIMALS;
const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const PositionSide = {
  Long: 1n,
  Short: 2n,
} as const;

function requireDeploymentAddress(deployment: any, key: string): string {
  const value = deployment.addresses?.[key];
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`Missing deployment address: ${key}`);
  }
  return value;
}

async function loadTreasuryFuturesMaintenanceDeployment() {
  const deployment = readLocalDeployment();

  const addresses = {
    sethxTimelock: requireLocalAddress(deployment, "sethxTimelock"),
    protocolTreasury: requireLocalAddress(deployment, "protocolTreasury"),
    treasuryAuthority: requireLocalAddress(deployment, "treasuryAuthority"),
    treasuryFuturesMaintenanceModule: requireDeploymentAddress(
      deployment,
      "treasuryFuturesMaintenanceModule",
    ),
    priceManager: requireLocalAddress(deployment, "priceManager"),
    futuresContract: requireLocalAddress(deployment, "futuresContract"),
  };

  const contracts = {
    protocolTreasury: await ethers.getContractAt(
      "ProtocolTreasury",
      addresses.protocolTreasury,
    ),
    treasuryAuthority: await ethers.getContractAt(
      "TreasuryAuthority",
      addresses.treasuryAuthority,
    ),
    treasuryFuturesMaintenanceModule: await ethers.getContractAt(
      "TreasuryFuturesMaintenanceModule",
      addresses.treasuryFuturesMaintenanceModule,
    ),
    priceManager: await ethers.getContractAt("PriceManager", addresses.priceManager),
    futuresContract: await ethers.getContractAt(
      "FuturesContract",
      addresses.futuresContract,
    ),
  };

  return { deployment, addresses, contracts };
}

async function loadActors() {
  const signers = await ethers.getSigners();
  return {
    deployer: signers[0],
    treasurer: signers[0],
    attacker: signers[6],
  };
}

async function expectBlocked(label: string, action: () => Promise<unknown>) {
  let blocked = false;
  try {
    await action();
  } catch (_err) {
    blocked = true;
  }
  expect(blocked, label).to.equal(true);
}

async function ensureLiquidityTreasurer(authority: any, timelock: any, treasurer: string) {
  const permissions = await authority.PERMISSION_MANAGE_LIQUIDITY();

  if (!(await authority.isTreasurer(treasurer))) {
    await (
      await authority
        .connect(timelock)
        .appointTreasurer(treasurer, "futures maintenance treasurer", permissions)
    ).wait();
    return;
  }

  const current = await authority.getTreasurerPermissions(treasurer);
  if ((current & permissions) !== permissions) {
    await (
      await authority.connect(timelock).setTreasurerPermissions(treasurer, current | permissions)
    ).wait();
  }

  if (await authority.frozenTreasurers(treasurer)) {
    await (await authority.connect(timelock).unfreezeTreasurer(treasurer)).wait();
  }

  if (await authority.killed()) {
    await (await authority.connect(timelock).unkillTreasury()).wait();
  }
}

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [pair, 8, initialPrice]);
  await oracle.waitForDeployment();
  return oracle;
}

async function registerFuturesOracle(priceManager: any, governance: any, oracle: any) {
  const oracleAddress = await oracle.getAddress();

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (await priceManager.connect(governance).approveOracle(oracleAddress)).wait();
  }

  if (!(await priceManager.isOracleApprovedFor(oracleAddress, OracleContext.FUTURE_SETTLEMENT))) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (await priceManager.connect(governance).syncOracleData(oracleAddress)).wait();
  expect(await priceManager.isOracleUsableForFutures(oracleAddress)).to.equal(true);

  return oracleAddress;
}

async function createFuturesMarket(
  futuresContract: any,
  governance: any,
  oracleAddress: string,
  label: string,
) {
  const marketKey = await futuresContract.computeMarketKey(oracleAddress);

  await (
    await futuresContract
      .connect(governance)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  return marketKey;
}

function findEvent(receipt: any, contract: any, eventName: string) {
  for (const log of receipt.logs) {
    try {
      const parsed = contract.interface.parseLog(log);
      if (parsed?.name === eventName) return parsed;
    } catch {
      // ignore logs from other contracts
    }
  }

  throw new Error(`${eventName} event not found`);
}

describe("Treasury futures maintenance module integration", function () {
  it("is deployed, approved as a treasury module, and controlled by liquidity treasurers", async function () {
    const { addresses, contracts } = await loadTreasuryFuturesMaintenanceDeployment();
    const actors = await loadActors();

    expect(addresses.treasuryFuturesMaintenanceModule).to.not.equal(ethers.ZeroAddress);
    expect(
      await contracts.protocolTreasury.approvedTreasuryModules(
        addresses.treasuryFuturesMaintenanceModule,
      ),
      "maintenance module approved in ProtocolTreasury",
    ).to.equal(true);

    await expectBlocked("attacker cannot call sync wrapper", () =>
      contracts.treasuryFuturesMaintenanceModule
        .connect(actors.attacker)
        .syncFuturesSettlementPrice(ethers.ZeroHash, "evil"),
    );

    await expectBlocked("attacker cannot call rebase wrapper", () =>
      contracts.treasuryFuturesMaintenanceModule
        .connect(actors.attacker)
        .rebaseFuturesLosingPositionsToBufferTarget(
          ethers.ZeroHash,
          PositionSide.Long,
          0n,
          1n,
          "evil",
        ),
    );
  });

  it("lets a liquidity treasurer sync a futures settlement price and receives capped ETH reimbursement", async function () {
    const { addresses, contracts } = await loadTreasuryFuturesMaintenanceDeployment();
    const actors = await loadActors();
    const timelock = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const treasurerAddress = await actors.treasurer.getAddress();

    await ensureLiquidityTreasurer(contracts.treasuryAuthority, timelock, treasurerAddress);

    if (!(await contracts.protocolTreasury.approvedExternalRecipients(treasurerAddress))) {
      await (
        await contracts.protocolTreasury
          .connect(timelock)
          .setApprovedExternalRecipient(treasurerAddress, true)
      ).wait();
    }

    if (!(await contracts.protocolTreasury.approvedTreasuryModules(addresses.treasuryFuturesMaintenanceModule))) {
      await (
        await contracts.protocolTreasury
          .connect(timelock)
          .setApprovedTreasuryModule(addresses.treasuryFuturesMaintenanceModule, true)
      ).wait();
    }

    await actors.deployer.sendTransaction({
      to: addresses.protocolTreasury,
      value: ethers.parseEther("1"),
    });

    const oracle = await deployMockOracle("TREASURY_FUTURES/ETH", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(contracts.priceManager, timelock, oracle);
    const marketKey = await createFuturesMarket(
      contracts.futuresContract,
      timelock,
      oracleAddress,
      "TREASURY_FUTURES/ETH",
    );

    await (await oracle.setPrice(UPDATED_PRICE)).wait();
    await (await contracts.priceManager.connect(timelock).syncOracleData(oracleAddress)).wait();

    const treasuryEthBefore = await ethers.provider.getBalance(addresses.protocolTreasury);

    const tx = await contracts.treasuryFuturesMaintenanceModule
      .connect(actors.treasurer)
      .syncFuturesSettlementPrice(marketKey, "sync futures test", {
        gasPrice: 1_000_000_000n,
      });
    const receipt = await tx.wait();

    const parsed = findEvent(
      receipt,
      contracts.treasuryFuturesMaintenanceModule,
      "FuturesSettlementPriceSyncedByTreasurer",
    );

    const reimbursement = parsed.args.reimbursement;
    expect(reimbursement, "reimbursement paid").to.be.gt(0n);
    expect(reimbursement, "reimbursement capped").to.be.lte(
      await contracts.treasuryFuturesMaintenanceModule.maxGasReimbursement(),
    );

    expect(await ethers.provider.getBalance(addresses.protocolTreasury)).to.equal(
      treasuryEthBefore - reimbursement,
    );

    const market = await contracts.futuresContract.getMarket(marketKey);
    expect(market.lastSettlementPrice).to.equal(UPDATED_PRICE);
  });

  it("lets a liquidity treasurer call the loser-rebase maintenance wrapper with reimbursement", async function () {
    const { addresses, contracts } = await loadTreasuryFuturesMaintenanceDeployment();
    const actors = await loadActors();
    const timelock = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const treasurerAddress = await actors.treasurer.getAddress();

    await ensureLiquidityTreasurer(contracts.treasuryAuthority, timelock, treasurerAddress);

    if (!(await contracts.protocolTreasury.approvedExternalRecipients(treasurerAddress))) {
      await (
        await contracts.protocolTreasury
          .connect(timelock)
          .setApprovedExternalRecipient(treasurerAddress, true)
      ).wait();
    }

    await actors.deployer.sendTransaction({
      to: addresses.protocolTreasury,
      value: ethers.parseEther("1"),
    });

    const oracle = await deployMockOracle("TREASURY_REBASE/ETH", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(contracts.priceManager, timelock, oracle);
    const marketKey = await createFuturesMarket(
      contracts.futuresContract,
      timelock,
      oracleAddress,
      "TREASURY_REBASE/ETH",
    );

    const treasuryEthBefore = await ethers.provider.getBalance(addresses.protocolTreasury);

    const tx = await contracts.treasuryFuturesMaintenanceModule
      .connect(actors.treasurer)
      .rebaseFuturesLosingPositionsToBufferTarget(
        marketKey,
        PositionSide.Long,
        0n,
        1n,
        "rebase futures test",
        { gasPrice: 1_000_000_000n },
      );
    const receipt = await tx.wait();

    const parsed = findEvent(
      receipt,
      contracts.treasuryFuturesMaintenanceModule,
      "FuturesLosingPositionsRebasedByTreasurer",
    );

    const reimbursement = parsed.args.reimbursement;
    expect(reimbursement, "reimbursement paid").to.be.gt(0n);
    expect(reimbursement, "reimbursement capped").to.be.lte(
      await contracts.treasuryFuturesMaintenanceModule.maxGasReimbursement(),
    );

    expect(await ethers.provider.getBalance(addresses.protocolTreasury)).to.equal(
      treasuryEthBefore - reimbursement,
    );
  });
});
