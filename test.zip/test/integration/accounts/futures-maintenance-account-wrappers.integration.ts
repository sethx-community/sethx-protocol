import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import {
  createLendingAccount,
  createNormalAccount,
} from "../helpers/accounts.js";
import { impersonateTimelock } from "../helpers/governance.js";

const { ethers } = await network.create();

const PRICE_DECIMALS = 8n;
const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const PositionSide = {
  Long: 1n,
  Short: 2n,
} as const;

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [
    pair,
    8,
    initialPrice,
  ]);
  await oracle.waitForDeployment();
  return oracle;
}

async function registerFuturesOracle(
  priceManager: any,
  governance: any,
  oracle: any,
) {
  const oracleAddress = await oracle.getAddress();

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (
      await priceManager.connect(governance).approveOracle(oracleAddress)
    ).wait();
  }

  if (
    !(await priceManager.isOracleApprovedFor(
      oracleAddress,
      OracleContext.FUTURE_SETTLEMENT,
    ))
  ) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (
    await priceManager.connect(governance).syncOracleData(oracleAddress)
  ).wait();
  return oracleAddress;
}

async function createMarket(contracts: any, timelock: any, label: string) {
  const oracle = await deployMockOracle(label, INITIAL_PRICE);
  const oracleAddress = await registerFuturesOracle(
    contracts.priceManager,
    timelock,
    oracle,
  );
  const marketKey =
    await contracts.futuresContract.computeMarketKey(oracleAddress);

  await (
    await contracts.futuresContract
      .connect(timelock)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  return marketKey;
}

describe("Futures maintenance account wrapper integration", function () {
  it("lets a normal Account call futures head liquidation and loser rebase maintenance wrappers", async function () {
    const { contracts, addresses } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelock = await impersonateTimelock(ethers, addresses.sethxTimelock);

    const account = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );

    const marketKey = await createMarket(
      contracts,
      timelock,
      "ACCOUNT_MAINT/ETH",
    );

    await expect(
      account
        .connect(actors.alice)
        .liquidateFuturesHead(
          await contracts.futuresContract.getAddress(),
          marketKey,
          PositionSide.Long,
          1n,
        ),
    ).to.not.revert(ethers);

    await expect(
      account
        .connect(actors.alice)
        .rebaseFuturesLosingPositionsToBufferTarget(
          await contracts.futuresContract.getAddress(),
          marketKey,
          PositionSide.Long,
          0n,
          1n,
        ),
    ).to.not.revert(ethers);
  });

  it("lets a LendingAccount call futures head liquidation and loser rebase maintenance wrappers", async function () {
    const { contracts, addresses } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelock = await impersonateTimelock(ethers, addresses.sethxTimelock);

    const lendingAccount = await createLendingAccount(
      ethers,
      contracts.lendingAccountFactory,
      contracts.accountRegistry,
      actors.bob,
    );

    const marketKey = await createMarket(
      contracts,
      timelock,
      "LENDING_ACCOUNT_MAINT/ETH",
    );

    await expect(
      lendingAccount
        .connect(actors.bob)
        .liquidateFuturesHead(
          await contracts.futuresContract.getAddress(),
          marketKey,
          PositionSide.Short,
          1n,
        ),
    ).to.not.revert(ethers);

    await expect(
      lendingAccount
        .connect(actors.bob)
        .rebaseFuturesLosingPositionsToBufferTarget(
          await contracts.futuresContract.getAddress(),
          marketKey,
          PositionSide.Short,
          0n,
          1n,
        ),
    ).to.not.revert(ethers);
  });
});
