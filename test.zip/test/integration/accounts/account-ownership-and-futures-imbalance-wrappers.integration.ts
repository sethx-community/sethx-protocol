import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import {
  createLendingAccount,
  createNormalAccount,
} from "../helpers/accounts.js";
import { impersonateTimelock } from "../helpers/governance.js";
import { expectRevert } from "../helpers/reverts.js";

const { ethers } = await network.create();

const ETH = ethers.ZeroAddress;
const WAD = 10n ** 18n;
const PRICE_DECIMALS = 8n;
const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const LIQUIDATION_PRICE_UP = 2_250n * 10n ** PRICE_DECIMALS;
const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;
const SIZE = 10n ** 15n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const PositionSide = {
  Long: 1n,
  Short: 2n,
} as const;

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [
    pair,
    8,
    initialPrice,
  ]);
  await oracle.waitForDeployment();
  return oracle;
}

async function registerFuturesOracle(
  priceManager: any,
  governance: any,
  oracle: any,
) {
  const oracleAddress = await oracle.getAddress();

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (
      await priceManager.connect(governance).approveOracle(oracleAddress)
    ).wait();
  }

  if (
    !(await priceManager.isOracleApprovedFor(
      oracleAddress,
      OracleContext.FUTURE_SETTLEMENT,
    ))
  ) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (await priceManager.syncOracleData(oracleAddress)).wait();
  expect(await priceManager.isOracleUsableForFutures(oracleAddress)).to.equal(
    true,
  );

  return oracleAddress;
}

async function createFuturesMarket(
  contracts: any,
  timelockSigner: any,
  oracleAddress: string,
  label: string,
) {
  const marketKey = await contracts.futuresContract.computeMarketKey(
    oracleAddress,
  );

  await (
    await contracts.futuresContract
      .connect(timelockSigner)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  expect((await contracts.futuresContract.getMarket(marketKey)).oracle).to.equal(
    oracleAddress,
  );

  return marketKey;
}

async function depositEthToAccount(account: any, owner: any, amount: bigint) {
  await (
    await account
      .connect(owner)
      .depositETH(await account.getAddress(), await account.vault(), {
        value: amount,
      })
  ).wait();
}

async function openMatchedPair(
  contracts: any,
  shortAccount: any,
  shortOwner: any,
  longAccount: any,
  longOwner: any,
  marketKey: string,
) {
  await (
    await shortAccount
      .connect(shortOwner)
      .placeOrderFutures(
        await contracts.futuresOrderBook.getAddress(),
        marketKey,
        1,
        INITIAL_PRICE,
        SIZE,
        0,
        ETH,
        ethers.ZeroAddress,
      )
  ).wait();

  await (
    await longAccount
      .connect(longOwner)
      .placeOrderFutures(
        await contracts.futuresOrderBook.getAddress(),
        marketKey,
        0,
        INITIAL_PRICE,
        SIZE,
        0,
        ETH,
        ethers.ZeroAddress,
      )
  ).wait();
}

async function syncFuturesSettlement(
  contracts: any,
  oracle: any,
  oracleAddress: string,
  marketKey: string,
  price: bigint,
) {
  await (await oracle.setPrice(price)).wait();
  await (await contracts.priceManager.syncOracleData(oracleAddress)).wait();
  await (await contracts.futuresContract.syncSettlementPrice(marketKey)).wait();
  expect(
    (await contracts.futuresContract.getMarket(marketKey)).lastSettlementPrice,
  ).to.equal(price);
}

function includesAddress(addresses: string[], expected: string): boolean {
  const normalized = ethers.getAddress(expected);
  return addresses.some((value) => ethers.getAddress(value) === normalized);
}

describe("Account ownership and futures imbalance wrapper integration", function () {
  it("keeps Account.owner and AccountRegistry.ownerOfAccount synchronized after accepted ownership transfer", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);

    const aliceAddress = await actors.alice.getAddress();
    const bobAddress = await actors.bob.getAddress();

    const account = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );
    const accountAddress = await account.getAddress();

    expect(await account.owner()).to.equal(aliceAddress);
    expect(await account.accountRegistry()).to.equal(addresses.accountRegistry);
    expect(await contracts.accountRegistry.ownerOfAccount(accountAddress)).to.equal(
      aliceAddress,
    );

    await (
      await account.connect(actors.alice).transferOwnership(bobAddress)
    ).wait();

    expect(await account.pendingOwner()).to.equal(bobAddress);
    await expectRevert(account.connect(actors.carol).acceptOwnership());

    await (await account.connect(actors.bob).acceptOwnership()).wait();

    expect(await account.owner()).to.equal(bobAddress);
    expect(await account.pendingOwner()).to.equal(ethers.ZeroAddress);
    expect(await contracts.accountRegistry.ownerOfAccount(accountAddress)).to.equal(
      bobAddress,
    );
    expect(
      await contracts.accountRegistry.isAccountOwner(bobAddress, accountAddress),
    ).to.equal(true);
    expect(
      await contracts.accountRegistry.isAccountOwner(aliceAddress, accountAddress),
    ).to.equal(false);

    const aliceAll = await contracts.accountRegistry.getAccounts(aliceAddress);
    const bobAll = await contracts.accountRegistry.getAccounts(bobAddress);
    const aliceNormal = await contracts.accountRegistry.getNormalAccounts(
      aliceAddress,
    );
    const bobNormal = await contracts.accountRegistry.getNormalAccounts(
      bobAddress,
    );

    expect(includesAddress(aliceAll, accountAddress)).to.equal(false);
    expect(includesAddress(aliceNormal, accountAddress)).to.equal(false);
    expect(includesAddress(bobAll, accountAddress)).to.equal(true);
    expect(includesAddress(bobNormal, accountAddress)).to.equal(true);

    await expectRevert(account.connect(actors.alice).setAccountName("old-owner"));
    await (await account.connect(actors.bob).setAccountName("new-owner")).wait();
    expect(await account.accountName()).to.equal("new-owner");
  });

  it("still blocks direct AccountRegistry owner transfers from EOAs", async function () {
    const { contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);

    const account = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );

    await expectRevert(
      contracts.accountRegistry
        .connect(actors.alice)
        .transferAccountOwner(
          await account.getAddress(),
          await actors.bob.getAddress(),
        ),
    );
  });

  it("matches futures imbalance through real Account and LendingAccount wrappers without account-address impersonation", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(
      ethers,
      addresses.sethxTimelock,
    );

    const oracle = await deployMockOracle("WRAP-IMBAL/ETH", INITIAL_PRICE);
    const oracleAddress = await registerFuturesOracle(
      contracts.priceManager,
      timelockSigner,
      oracle,
    );
    const marketKey = await createFuturesMarket(
      contracts,
      timelockSigner,
      oracleAddress,
      "WRAP-IMBAL",
    );

    const shortAccount = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );
    const longAccount = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.bob,
    );
    const liquidatorAccount = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.carol,
    );
    const sellerAccount = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.dave,
    );
    const normalMatcher = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.lp1,
    );
    const lendingMatcher = await createLendingAccount(
      ethers,
      contracts.lendingAccountFactory,
      contracts.accountRegistry,
      actors.lp2,
    );

    const shortAddress = await shortAccount.getAddress();
    const longAddress = await longAccount.getAddress();
    const sellerAddress = await sellerAccount.getAddress();

    const deposit = 4n * WAD;
    await depositEthToAccount(shortAccount, actors.alice, deposit);
    await depositEthToAccount(longAccount, actors.bob, deposit);
    await depositEthToAccount(sellerAccount, actors.dave, deposit);

    // Normal Account wrapper reaches FuturesOrderBook.matchImbalance and returns cleanly when no imbalance exists.
    await expect(
      normalMatcher
        .connect(actors.lp1)
        .matchFuturesImbalance(
          await contracts.futuresOrderBook.getAddress(),
          marketKey,
          1n,
        ),
    ).to.not.revert(ethers);

    await openMatchedPair(
      contracts,
      shortAccount,
      actors.alice,
      longAccount,
      actors.bob,
      marketKey,
    );

    await syncFuturesSettlement(
      contracts,
      oracle,
      oracleAddress,
      marketKey,
      LIQUIDATION_PRICE_UP,
    );

    // Liquidation also goes through the existing Account wrapper, not account-contract impersonation.
    await (
      await liquidatorAccount
        .connect(actors.carol)
        .liquidateFuturesPosition(
          await contracts.futuresContract.getAddress(),
          marketKey,
          shortAddress,
        )
    ).wait();

    const shortAfter = await contracts.futuresContract.getPosition(
      shortAddress,
      marketKey,
    );
    expect(shortAfter.size).to.equal(0n);
    expect(await contracts.futuresContract.totalLongs(marketKey)).to.equal(SIZE);
    expect(await contracts.futuresContract.totalShorts(marketKey)).to.equal(0n);

    const imbalanceBefore = await contracts.futuresContract.getImbalanceOrder(
      marketKey,
    );
    expect(imbalanceBefore.active).to.equal(true);
    expect(imbalanceBefore.syntheticMakerSide).to.equal(PositionSide.Long);
    expect(imbalanceBefore.amount).to.equal(SIZE);

    await (
      await sellerAccount
        .connect(actors.dave)
        .placeOrderFutures(
          await contracts.futuresOrderBook.getAddress(),
          marketKey,
          1,
          LIQUIDATION_PRICE_UP,
          SIZE,
          0,
          ETH,
          ethers.ZeroAddress,
        )
    ).wait();

    // LendingAccount wrapper is the actual caller and reward recipient.
    await (
      await lendingMatcher
        .connect(actors.lp2)
        .matchFuturesImbalance(
          await contracts.futuresOrderBook.getAddress(),
          marketKey,
          10n,
        )
    ).wait();

    const sellerPosition = await contracts.futuresContract.getPosition(
      sellerAddress,
      marketKey,
    );
    expect(sellerPosition.side).to.equal(PositionSide.Short);
    expect(sellerPosition.size).to.equal(SIZE);
    expect(await contracts.futuresContract.totalLongs(marketKey)).to.equal(SIZE);
    expect(await contracts.futuresContract.totalShorts(marketKey)).to.equal(SIZE);
    expect(await contracts.futuresContract.getOpenInterestImbalance(marketKey)).to.equal(0n);

    const longPosition = await contracts.futuresContract.getPosition(
      longAddress,
      marketKey,
    );
    expect(longPosition.side).to.equal(PositionSide.Long);
    expect(longPosition.size).to.equal(SIZE);
  });
});
