import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import { createNormalAccount } from "../helpers/accounts.js";

const { ethers } = await network.create();

const ETH = ethers.ZeroAddress;
const REFERRAL_SHARE_BPS = 3_000n;
const BPS_DENOMINATOR = 10_000n;

async function impersonateProtocolCaller(address: string) {
  await ethers.provider.send("hardhat_setBalance", [
    address,
    "0x56BC75E2D63100000",
  ]);
  await ethers.provider.send("hardhat_impersonateAccount", [address]);
  return ethers.getSigner(address);
}

async function stopImpersonating(address: string) {
  await ethers.provider.send("hardhat_stopImpersonatingAccount", [address]);
}

async function depositAndLockEth(
  vault: any,
  account: any,
  owner: any,
  accountAddress: string,
  orderbookAddress: string,
  amount: bigint,
) {
  await (
    await account
      .connect(owner)
      .depositETH(accountAddress, await vault.getAddress(), { value: amount })
  ).wait();

  const orderbookSigner = await impersonateProtocolCaller(orderbookAddress);
  try {
    await (
      await vault.connect(orderbookSigner).lockETH(accountAddress, amount)
    ).wait();
  } finally {
    await stopImpersonating(orderbookAddress);
  }
}

describe("Vault referral fee sharing", function () {
  it("sends the full fee to treasury when no referrer is supplied", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);

    const payer = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );
    const payerAddress = await payer.getAddress();
    const feeAmount = ethers.parseEther("1");

    await depositAndLockEth(
      contracts.vault,
      payer,
      actors.alice,
      payerAddress,
      addresses.tokenSpotOrderBook,
      feeAmount,
    );

    const treasuryBefore = await contracts.vault.treasuryEthBalance();

    const orderbookSigner = await impersonateProtocolCaller(
      addresses.tokenSpotOrderBook,
    );
    try {
      await (
        await contracts.vault
          .connect(orderbookSigner)
          .chargeFee(
            payerAddress,
            ETH,
            feeAmount,
            "referral_zero_referrer_test",
            ETH,
          )
      ).wait();
    } finally {
      await stopImpersonating(addresses.tokenSpotOrderBook);
    }

    expect(await contracts.vault.treasuryEthBalance()).to.equal(
      treasuryBefore + feeAmount,
    );
  });

  it("tracks the referral threshold first, then shares future fees with the approved referrer", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);

    const payer = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.alice,
    );
    const referrer = await createNormalAccount(
      ethers,
      contracts.accountFactory,
      contracts.accountRegistry,
      actors.carol,
    );

    const payerAddress = await payer.getAddress();
    const referrerAddress = await referrer.getAddress();

    const thresholdFee = ethers.parseEther("30");
    const sharedFee = ethers.parseEther("10");
    const expectedReferralShare =
      (sharedFee * REFERRAL_SHARE_BPS) / BPS_DENOMINATOR;

    await depositAndLockEth(
      contracts.vault,
      payer,
      actors.alice,
      payerAddress,
      addresses.tokenSpotOrderBook,
      thresholdFee + sharedFee,
    );

    const treasuryBefore = await contracts.vault.treasuryEthBalance();
    const referrerBefore = await contracts.vault.ethBalances(referrerAddress);

    const orderbookSigner = await impersonateProtocolCaller(
      addresses.tokenSpotOrderBook,
    );
    try {
      await (
        await contracts.vault
          .connect(orderbookSigner)
          .chargeFee(
            payerAddress,
            ETH,
            thresholdFee,
            "referral_threshold_test",
            referrerAddress,
          )
      ).wait();

      expect(
        await contracts.vault.isApprovedReferrer(referrerAddress),
      ).to.equal(true);
      expect(
        await contracts.vault.referredFeeEthValue(referrerAddress),
      ).to.equal(thresholdFee);
      expect(await contracts.vault.ethBalances(referrerAddress)).to.equal(
        referrerBefore,
      );
      expect(await contracts.vault.treasuryEthBalance()).to.equal(
        treasuryBefore + thresholdFee,
      );

      await (
        await contracts.vault
          .connect(orderbookSigner)
          .chargeFee(
            payerAddress,
            ETH,
            sharedFee,
            "referral_share_test",
            referrerAddress,
          )
      ).wait();
    } finally {
      await stopImpersonating(addresses.tokenSpotOrderBook);
    }

    expect(await contracts.vault.ethBalances(referrerAddress)).to.equal(
      referrerBefore + expectedReferralShare,
    );
    expect(await contracts.vault.treasuryEthBalance()).to.equal(
      treasuryBefore + thresholdFee + sharedFee - expectedReferralShare,
    );
  });
});
