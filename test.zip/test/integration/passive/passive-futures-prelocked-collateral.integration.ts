import { expect } from "chai";
import { network } from "hardhat";

import {
  loadActors,
  loadIntegratedDeployment,
} from "../helpers/integration-deployment.js";
import { createNormalAccount } from "../helpers/accounts.js";
import { impersonateTimelock } from "../helpers/governance.js";
import { expectRevert } from "../helpers/reverts.js";

const { ethers } = await network.create();

const ETH = ethers.ZeroAddress;
const WAD = 10n ** 18n;
const PRICE_DECIMALS = 8n;

const INITIAL_PRICE = 2_000n * 10n ** PRICE_DECIMALS;
const ASK_BELOW_SETTLEMENT = 1_900n * 10n ** PRICE_DECIMALS;
const BID_ABOVE_SETTLEMENT = 2_100n * 10n ** PRICE_DECIMALS;

const INITIAL_MARGIN_BPS = 1_000n;
const MAINTENANCE_MARGIN_BPS = 500n;
const MULTIPLIER = 1n;
const SIZE = 10n ** 15n;

const OracleContext = {
  FUTURE_SETTLEMENT: 2,
} as const;

const Side = {
  Buy: 0,
  Sell: 1,
} as const;

const PositionSide = {
  None: 0n,
  Long: 1n,
  Short: 2n,
} as const;

function isOpenPosition(p: any): boolean {
  return p.size > 0n && (p.side === PositionSide.Long || p.side === PositionSide.Short);
}

function normalizePrice(rawPrice: bigint, oracleDecimals = 8n, marginDecimals = 18n): bigint {
  if (oracleDecimals === marginDecimals) return rawPrice;
  if (oracleDecimals < marginDecimals) return rawPrice * 10n ** (marginDecimals - oracleDecimals);
  return rawPrice / 10n ** (oracleDecimals - marginDecimals);
}

function initialMarginRequired(size: bigint, rawPrice = INITIAL_PRICE): bigint {
  return (size * MULTIPLIER * normalizePrice(rawPrice) * INITIAL_MARGIN_BPS) / (10_000n * WAD);
}

function variationBetweenPrices(size: bigint, priceA: bigint, priceB: bigint): bigint {
  const a = normalizePrice(priceA);
  const b = normalizePrice(priceB);
  const diff = a > b ? a - b : b - a;

  return (diff * size * MULTIPLIER) / WAD;
}

async function deployMockOracle(pair: string, initialPrice: bigint) {
  const oracle = await ethers.deployContract("MockPriceOracle", [pair, 8, initialPrice]);
  await oracle.waitForDeployment();
  return oracle;
}

async function registerFuturesOracle(priceManager: any, governance: any, oracle: any) {
  const oracleAddress = await oracle.getAddress();

  if (!(await priceManager.isApprovedOracle(oracleAddress))) {
    await (await priceManager.connect(governance).approveOracle(oracleAddress)).wait();
  }

  if (!(await priceManager.isOracleApprovedFor(oracleAddress, OracleContext.FUTURE_SETTLEMENT))) {
    await (
      await priceManager
        .connect(governance)
        .approveOracleForContext(oracleAddress, OracleContext.FUTURE_SETTLEMENT)
    ).wait();
  }

  await (await priceManager.syncOracleData(oracleAddress)).wait();
  expect(await priceManager.isOracleUsableForFutures(oracleAddress)).to.equal(true);

  return oracleAddress;
}

async function createFuturesMarket(
  contracts: any,
  timelockSigner: any,
  oracleAddress: string,
  label: string,
) {
  const marketKey = await contracts.futuresContract.computeMarketKey(oracleAddress);

  await (
    await contracts.futuresContract
      .connect(timelockSigner)
      .createMarket(
        label,
        oracleAddress,
        INITIAL_MARGIN_BPS,
        MAINTENANCE_MARGIN_BPS,
        MULTIPLIER,
        INITIAL_PRICE,
      )
  ).wait();

  const market = await contracts.futuresContract.getMarket(marketKey);
  expect(market.oracle).to.equal(oracleAddress);
  expect(market.lastSettlementPrice).to.equal(INITIAL_PRICE);
  expect(await contracts.futuresContract.marketActive(marketKey)).to.equal(true);

  return marketKey;
}

async function createMarketAndPool(contracts: any, timelockSigner: any, label: string) {
  const oracle = await deployMockOracle(`${label}/USD`, INITIAL_PRICE);
  const oracleAddress = await registerFuturesOracle(contracts.priceManager, timelockSigner, oracle);
  const marketKey = await createFuturesMarket(contracts, timelockSigner, oracleAddress, label);

  await (
    await contracts.passiveFuturesPoolFactory
      .connect(timelockSigner)
      .createPool(marketKey, await contracts.passiveFuturesSnapshotPublisher.getAddress())
  ).wait();

  const poolInfo = await contracts.passiveFuturesPoolFactory.poolForMarket(marketKey);
  const poolAddress = poolInfo.pool ?? poolInfo[0];

  expect(poolAddress).to.not.equal(ethers.ZeroAddress);
  expect(await contracts.futuresOrderBook.passivePoolForMarket(marketKey)).to.equal(poolAddress);
  expect(await contracts.accountRegistry.isAccount(poolAddress)).to.equal(true);
  expect(await contracts.passiveFuturesPoolFactory.isPoolActive(marketKey)).to.equal(true);

  const pool = await ethers.getContractAt("PassiveLiquidityPool", poolAddress);
  const snap = await pool.getSnapshot();

  expect(snap.registeredAccount).to.equal(true);
  expect(snap.marketKey).to.equal(marketKey);
  expect(snap.active).to.equal(true);

  return { oracle, oracleAddress, marketKey, pool, poolAddress };
}

async function depositEthToAccount(account: any, owner: any, amount: bigint) {
  await (
    await account
      .connect(owner)
      .depositETH(await account.getAddress(), await account.vault(), { value: amount })
  ).wait();
}

async function createFundedNormalAccount(
  contracts: any,
  owner: any,
  amount = 3n * WAD,
) {
  const account = await createNormalAccount(
    ethers,
    contracts.accountFactory,
    contracts.accountRegistry,
    owner,
  );

  await depositEthToAccount(account, owner, amount);
  return account;
}

async function publishThroughTreasurer(
  contracts: any,
  treasurer: any,
  marketKey: string,
  bidPrice: bigint,
  bidSize: bigint,
  askPrice: bigint,
  askSize: bigint,
  validForBlocks: bigint,
  memo = "passive collateral regression quote",
) {
  await (
    await contracts.passiveFuturesSnapshotPublisher
      .connect(treasurer)
      .publishPassiveSnapshot(
        marketKey,
        bidPrice,
        bidSize,
        askPrice,
        askSize,
        validForBlocks,
        memo,
      )
  ).wait();
}

async function placeFuturesOrder(
  contracts: any,
  account: any,
  owner: any,
  marketKey: string,
  side: number,
  price: bigint,
  size = SIZE,
) {
  await (
    await account
      .connect(owner)
      .placeOrderFutures(
        await contracts.futuresOrderBook.getAddress(),
        marketKey,
        side,
        price,
        size,
        0,
        ETH,
        ethers.ZeroAddress,
      )
  ).wait();
}

async function expectEthAccounting(
  contracts: any,
  account: string,
  expectedTotal: bigint,
  expectedLocked: bigint,
  label: string,
) {
  const total = await contracts.vault.ethBalances(account);
  const locked = await contracts.vault.ethLocked(account);
  const view = await contracts.vault.getEthBalances(account);

  expect(total, `${label}: total ETH`).to.equal(expectedTotal);
  expect(locked, `${label}: locked ETH`).to.equal(expectedLocked);
  expect(view.reservedOrderEth, `${label}: getEthBalances locked ETH`).to.equal(expectedLocked);
  expect(view.freeEth, `${label}: free ETH`).to.equal(expectedTotal - expectedLocked);
  expect(locked, `${label}: locked <= total`).to.be.lte(total);
}

describe("Passive futures prelocked collateral regression", function () {
  it("rejects a passive quote when free ETH covers opening margin but not total need", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const { marketKey, pool, poolAddress } = await createMarketAndPool(
      contracts,
      timelockSigner,
      "PF-PRELOCK-PUBLISH-CAP",
    );

    const margin = initialMarginRequired(SIZE);
    const adverseVariation = variationBetweenPrices(SIZE, INITIAL_PRICE, ASK_BELOW_SETTLEMENT);
    const depositThatCoversMarginButNotNeed = margin + adverseVariation / 2n;

    expect(depositThatCoversMarginButNotNeed).to.be.gt(margin);
    expect(depositThatCoversMarginButNotNeed).to.be.lt(margin + adverseVariation);

    await (await pool.connect(actors.lp1).deposit({ value: depositThatCoversMarginButNotNeed })).wait();
    await expectEthAccounting(
      contracts,
      poolAddress,
      depositThatCoversMarginButNotNeed,
      0n,
      "after underfunded LP deposit",
    );

    await expectRevert(
      publishThroughTreasurer(
        contracts,
        actors.treasurer,
        marketKey,
        0n,
        0n,
        ASK_BELOW_SETTLEMENT,
        SIZE,
        20n,
        "underfunded quote should account for variation plus margin",
      ),
    );
  });

  it("fills a passive ask below settlement by prelocking adverse variation plus opening margin", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const { marketKey, pool, poolAddress } = await createMarketAndPool(
      contracts,
      timelockSigner,
      "PF-PRELOCK-ASK",
    );

    const lpDeposit = 2n * WAD;
    await (await pool.connect(actors.lp1).deposit({ value: lpDeposit })).wait();

    const margin = initialMarginRequired(SIZE);
    const adverseVariation = variationBetweenPrices(SIZE, INITIAL_PRICE, ASK_BELOW_SETTLEMENT);
    expect(lpDeposit).to.be.gt(margin + adverseVariation);

    await publishThroughTreasurer(
      contracts,
      actors.treasurer,
      marketKey,
      0n,
      0n,
      ASK_BELOW_SETTLEMENT,
      SIZE,
      20n,
      "passive ask below settlement should prelock full need",
    );

    const taker = await createFundedNormalAccount(contracts, actors.bob);
    const takerAddress = await taker.getAddress();

    await expectEthAccounting(contracts, poolAddress, lpDeposit, 0n, "pool before fill");

    await placeFuturesOrder(
      contracts,
      taker,
      actors.bob,
      marketKey,
      Side.Buy,
      ASK_BELOW_SETTLEMENT,
    );

    const poolShort = await contracts.futuresContract.getPosition(poolAddress, marketKey);
    const takerLong = await contracts.futuresContract.getPosition(takerAddress, marketKey);

    expect(isOpenPosition(poolShort), "pool position open").to.equal(true);
    expect(poolShort.side, "pool is passive seller/short").to.equal(PositionSide.Short);
    expect(poolShort.size).to.equal(SIZE);
    expect(poolShort.margin).to.equal(margin);

    expect(isOpenPosition(takerLong), "taker position open").to.equal(true);
    expect(takerLong.side, "taker is long").to.equal(PositionSide.Long);
    expect(takerLong.size).to.equal(SIZE);
    expect(takerLong.margin).to.equal(margin);

    // Passive seller owes variation because execution is below settlement.
    // The temporary prelock should be spent on variation, leaving only opening margin locked.
    await expectEthAccounting(
      contracts,
      poolAddress,
      lpDeposit - adverseVariation,
      margin,
      "pool after below-settlement ask fill",
    );

    const snapshot = await contracts.futuresOrderBook.passiveSnapshot(marketKey);
    expect(snapshot.exists).to.equal(false);
  });

  it("fills a passive bid above settlement by prelocking adverse variation plus opening margin", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const { marketKey, pool, poolAddress } = await createMarketAndPool(
      contracts,
      timelockSigner,
      "PF-PRELOCK-BID",
    );

    const lpDeposit = 2n * WAD;
    await (await pool.connect(actors.lp1).deposit({ value: lpDeposit })).wait();

    const margin = initialMarginRequired(SIZE);
    const adverseVariation = variationBetweenPrices(SIZE, INITIAL_PRICE, BID_ABOVE_SETTLEMENT);
    expect(lpDeposit).to.be.gt(margin + adverseVariation);

    await publishThroughTreasurer(
      contracts,
      actors.treasurer,
      marketKey,
      BID_ABOVE_SETTLEMENT,
      SIZE,
      0n,
      0n,
      20n,
      "passive bid above settlement should prelock full need",
    );

    const taker = await createFundedNormalAccount(contracts, actors.alice);
    const takerAddress = await taker.getAddress();

    await expectEthAccounting(contracts, poolAddress, lpDeposit, 0n, "pool before fill");

    await placeFuturesOrder(
      contracts,
      taker,
      actors.alice,
      marketKey,
      Side.Sell,
      BID_ABOVE_SETTLEMENT,
    );

    const poolLong = await contracts.futuresContract.getPosition(poolAddress, marketKey);
    const takerShort = await contracts.futuresContract.getPosition(takerAddress, marketKey);

    expect(isOpenPosition(poolLong), "pool position open").to.equal(true);
    expect(poolLong.side, "pool is passive buyer/long").to.equal(PositionSide.Long);
    expect(poolLong.size).to.equal(SIZE);
    expect(poolLong.margin).to.equal(margin);

    expect(isOpenPosition(takerShort), "taker position open").to.equal(true);
    expect(takerShort.side, "taker is short").to.equal(PositionSide.Short);
    expect(takerShort.size).to.equal(SIZE);
    expect(takerShort.margin).to.equal(margin);

    // Passive buyer owes variation because execution is above settlement.
    // The temporary prelock should be spent on variation, leaving only opening margin locked.
    await expectEthAccounting(
      contracts,
      poolAddress,
      lpDeposit - adverseVariation,
      margin,
      "pool after above-settlement bid fill",
    );

    const snapshot = await contracts.futuresOrderBook.passiveSnapshot(marketKey);
    expect(snapshot.exists).to.equal(false);
  });

  it("prelocks only adverse variation, not new margin, when the passive fill fully closes the pool position", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const { marketKey, pool, poolAddress } = await createMarketAndPool(
      contracts,
      timelockSigner,
      "PF-PRELOCK-CLOSE",
    );

    const lpDeposit = 2n * WAD;
    await (await pool.connect(actors.lp1).deposit({ value: lpDeposit })).wait();

    const taker = await createFundedNormalAccount(contracts, actors.bob);
    const takerAddress = await taker.getAddress();

    const margin = initialMarginRequired(SIZE);
    const closingVariation = variationBetweenPrices(SIZE, INITIAL_PRICE, BID_ABOVE_SETTLEMENT);

    // First open pool short versus taker long at settlement, so there is no variation.
    await publishThroughTreasurer(
      contracts,
      actors.treasurer,
      marketKey,
      0n,
      0n,
      INITIAL_PRICE,
      SIZE,
      20n,
      "open passive short at settlement",
    );

    await placeFuturesOrder(contracts, taker, actors.bob, marketKey, Side.Buy, INITIAL_PRICE);

    let poolPosition = await contracts.futuresContract.getPosition(poolAddress, marketKey);
    let takerPosition = await contracts.futuresContract.getPosition(takerAddress, marketKey);

    expect(poolPosition.side).to.equal(PositionSide.Short);
    expect(poolPosition.size).to.equal(SIZE);
    expect(poolPosition.margin).to.equal(margin);
    expect(takerPosition.side).to.equal(PositionSide.Long);
    expect(takerPosition.size).to.equal(SIZE);
    await expectEthAccounting(contracts, poolAddress, lpDeposit, margin, "after opening passive short");

    // Now pool buys above settlement to close its short. Buy side pays the
    // execution-vs-settlement variation, but the passive side should not lock any
    // new opening margin for a pure close. After processTrade closes the position,
    // the old position margin must be unlocked.
    await publishThroughTreasurer(
      contracts,
      actors.treasurer,
      marketKey,
      BID_ABOVE_SETTLEMENT,
      SIZE,
      0n,
      0n,
      20n,
      "close passive short above settlement",
    );

    await placeFuturesOrder(contracts, taker, actors.bob, marketKey, Side.Sell, BID_ABOVE_SETTLEMENT);

    poolPosition = await contracts.futuresContract.getPosition(poolAddress, marketKey);
    takerPosition = await contracts.futuresContract.getPosition(takerAddress, marketKey);

    expect(poolPosition.size).to.equal(0n);
    expect(takerPosition.size).to.equal(0n);

    await expectEthAccounting(
      contracts,
      poolAddress,
      lpDeposit - closingVariation,
      0n,
      "after passive close with adverse variation",
    );

    const snapshot = await contracts.futuresOrderBook.passiveSnapshot(marketKey);
    expect(snapshot.exists).to.equal(false);
  });

  it("rechecks passive free collateral at fill time and leaves the taker order resting when capacity disappeared", async function () {
    const { addresses, contracts } = await loadIntegratedDeployment(ethers);
    const actors = await loadActors(ethers);
    const timelockSigner = await impersonateTimelock(ethers, addresses.sethxTimelock);
    const { marketKey, pool, poolAddress } = await createMarketAndPool(
      contracts,
      timelockSigner,
      "PF-PRELOCK-FILL-CAP",
    );

    const margin = initialMarginRequired(SIZE);
    const adverseVariation = variationBetweenPrices(SIZE, INITIAL_PRICE, ASK_BELOW_SETTLEMENT);
    const passiveNeed = margin + adverseVariation;

    const lpDeposit = passiveNeed + ethers.parseEther("0.05");
    const withdrawal = ethers.parseEther("0.06");

    await (await pool.connect(actors.lp1).deposit({ value: lpDeposit })).wait();
    await expectEthAccounting(contracts, poolAddress, lpDeposit, 0n, "after LP deposit");

    await publishThroughTreasurer(
      contracts,
      actors.treasurer,
      marketKey,
      0n,
      0n,
      ASK_BELOW_SETTLEMENT,
      SIZE,
      20n,
      "quote initially has enough passive capacity",
    );

    await (await pool.connect(actors.lp1).requestWithdrawal(withdrawal)).wait();
    await (await pool.connect(actors.lp2).processWithdrawal(await actors.lp1.getAddress())).wait();

    const totalAfterWithdrawal = await contracts.vault.ethBalances(poolAddress);
    const lockedAfterWithdrawal = await contracts.vault.ethLocked(poolAddress);
    const viewAfterWithdrawal = await contracts.vault.getEthBalances(poolAddress);

    expect(totalAfterWithdrawal).to.equal(lpDeposit - withdrawal);
    expect(lockedAfterWithdrawal).to.equal(0n);
    expect(viewAfterWithdrawal.freeEth, "free collateral must now be below passive fill need").to.be.lt(passiveNeed);

    const taker = await createFundedNormalAccount(contracts, actors.carol);
    const takerAddress = await taker.getAddress();
    const takerOrderId = await contracts.futuresOrderBook.nextOrderId();

    await placeFuturesOrder(
      contracts,
      taker,
      actors.carol,
      marketKey,
      Side.Buy,
      ASK_BELOW_SETTLEMENT,
    );

    const poolPosition = await contracts.futuresContract.getPosition(poolAddress, marketKey);
    const takerPosition = await contracts.futuresContract.getPosition(takerAddress, marketKey);

    expect(poolPosition.size).to.equal(0n);
    expect(takerPosition.size).to.equal(0n);
    await expectEthAccounting(contracts, poolAddress, lpDeposit - withdrawal, 0n, "after skipped passive fill");

    const snapshot = await contracts.futuresOrderBook.passiveSnapshot(marketKey);
    expect(snapshot.exists).to.equal(true);
    expect(snapshot.bestAsk.remainingSize).to.equal(SIZE);

    const restingOrder = await contracts.futuresOrderBook.ordersById(takerOrderId);
    expect(restingOrder.user).to.equal(takerAddress);
    expect(restingOrder.amount).to.equal(SIZE);

    const buyBook = await contracts.futuresOrderBook.getBook(marketKey, true);
    expect(buyBook).to.deep.equal([takerOrderId]);
  });
});
