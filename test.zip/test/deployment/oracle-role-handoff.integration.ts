import { expect } from "chai";
import { network } from "hardhat";

import { readLocalDeployment } from "../helpers/deployment-reader.js";

const { ethers } = await network.create();

const TOKEN_ETH_ORACLES = [
  {
    key: "usdcEthOracle",
    contractName: "ChainlinkUsdcEthOracle",
    label: "USDC/ETH oracle",
  },
  {
    key: "wbtcEthOracle",
    contractName: "ChainlinkWbtcEthOracle",
    label: "WBTC/ETH oracle",
  },
] as const;

function requireStage(deployment: ReturnType<typeof readLocalDeployment>, stage: string) {
  if (!deployment.stages?.[stage]) {
    throw new Error(`Full deployment must include Stage ${stage}`);
  }
}

function requireAddress(deployment: ReturnType<typeof readLocalDeployment>, key: string): string {
  const value = (deployment.addresses as Record<string, unknown>)[key];
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`Missing deployment address: ${key}`);
  }
  expect(value, `${key} address`).to.match(/^0x[a-fA-F0-9]{40}$/);
  return value;
}

async function expectRole(
  contractName: string,
  address: string,
  roleGetter: string,
  holder: string,
  expected: boolean,
) {
  const contract = await ethers.getContractAt(contractName, address);
  const role = await contract[roleGetter]();

  expect(await contract.hasRole(role, holder)).to.equal(expected);
}

describe("Token/ETH Chainlink oracle governance handoff", function () {
  it("grants Timelock admin and governor roles on deployed token/ETH oracles after Stage 88", async function () {
    const deployment = readLocalDeployment();
    requireStage(deployment, "88");

    const timelock = requireAddress(deployment, "sethxTimelock");

    for (const target of TOKEN_ETH_ORACLES) {
      const oracleAddress = requireAddress(deployment, target.key);

      await expectRole(
        target.contractName,
        oracleAddress,
        "DEFAULT_ADMIN_ROLE",
        timelock,
        true,
      );

      await expectRole(
        target.contractName,
        oracleAddress,
        "GOVERNOR_ROLE",
        timelock,
        true,
      );
    }
  });

  it("removes deployer bootstrap admin and governor roles on token/ETH oracles after Stage 89", async function () {
    const deployment = readLocalDeployment();
    requireStage(deployment, "89");

    const [deployer] = await ethers.getSigners();
    const deployerAddress = await deployer.getAddress();

    for (const target of TOKEN_ETH_ORACLES) {
      const oracleAddress = requireAddress(deployment, target.key);

      await expectRole(
        target.contractName,
        oracleAddress,
        "DEFAULT_ADMIN_ROLE",
        deployerAddress,
        false,
      );

      await expectRole(
        target.contractName,
        oracleAddress,
        "GOVERNOR_ROLE",
        deployerAddress,
        false,
      );
    }
  });
});
