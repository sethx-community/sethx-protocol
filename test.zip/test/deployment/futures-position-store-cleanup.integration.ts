import { expect } from "chai";
import { network } from "hardhat";

import { loadIntegratedDeployment } from "../integration/helpers/integration-deployment.js";

const { ethers } = await network.create();

function contractHasFunction(contract: any, functionName: string): boolean {
  return contract.interface.fragments.some(
    (fragment: any) => fragment.type === "function" && fragment.name === functionName,
  );
}

describe("FuturesPositionStore cleanup", function () {
  it("keeps only liquidation/reference index surfaces and removes dead position/OI storage surfaces", async function () {
    const { contracts } = await loadIntegratedDeployment(ethers);

    const positionStoreAddress = await contracts.futuresContract.positionStore();
    const positionStore = await ethers.getContractAt(
      "FuturesPositionStore",
      positionStoreAddress,
    );

    for (const name of [
      "positions",
      "totalLongs",
      "totalShorts",
      "setPosition",
      "deletePosition",
      "increaseOi",
      "decreaseOi",
      "getPosition",
      "reindexLiquidation",
      "clearLiquidation",
      "reindexReferencePrice",
      "clearReferencePrice",
    ]) {
      expect(
        contractHasFunction(positionStore, name),
        `${name} should not be exposed by FuturesPositionStore`,
      ).to.equal(false);
    }

    for (const name of [
      "reindexLiquidationPosition",
      "clearLiquidationPosition",
      "reindexReferencePricePosition",
      "clearReferencePricePosition",
      "getLiquidationHead",
      "getLiquidationNode",
      "getReferencePriceHead",
      "getReferencePriceNode",
    ]) {
      expect(
        contractHasFunction(positionStore, name),
        `${name} should remain exposed by FuturesPositionStore`,
      ).to.equal(true);
    }
  });
});
